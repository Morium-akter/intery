<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "", "morium");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
 $event_title = mysqli_real_escape_string($link, $_REQUEST['event_title']);
 $date = mysqli_real_escape_string($link, $_REQUEST['date']);

// Attempt update query execution
$sql = "INSERT into event_title (event_title,date) VALUES ('$event_title','$date')";


if(mysqli_query($link, $sql)){
	header('Location: New_Event_form.php');
    exit;
} else {
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>