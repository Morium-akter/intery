<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
	<link rel="stylesheet" 
     href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"> 
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; }
        .wrapper{ width: 350px; padding: 20px; }
		* {
			  margin: 0;
			}
			.top_head{
				overflow:hidden;
				height:70px;
				background:#128C41;
				text-align: center;
				padding:5px;
				
			}
			.top_child{
				overflow:hidden;
				height:60px;
				background:#333;
			}

			.top_child ul{
				margin-left:0px;
			}

			.top_child ul li{
			float:left;
			padding:17px;
			list-style-type: none;
			}

			.top_child ul li a{
			color:white;
			text-decoration:none;
			padding: 10px;
			}
			.top_child ul li a:hover{
				background:white;
				color:black;
				padding:10px 10px;
			}
			.middle_area
			{
			background-color:#B3CBD2;
			width:100%;
			overflow:hidden;
			height:500px;
			
			}
			table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 50%;
  text-align:center;
  margin-left:300px;
}

td, th {
  border: 1px solid #B3CBD2;;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}			
				
    </style>
</head>
<body>
<div class="top_head">
		  <h1>IUBAT IT society management system</h1>
		</div>
		<div class="top_child">
			<ul>
				<li><a href="../after_admin_login_home.php">Home</a></li>
				<li><a href="">Notice</a></li>
				<li><a href="loantype.html">Mentoring Class</a></li>
				<li><a href="#">Member</a></li>
				<li><a href="#">Event</a></li>
				<li><a href="#">Finance</a></li>
				<li><a href="logout.php">Logout</a></li>
			</ul>
		</div>
<div class="middle_area">
		
		<h3 style="text-align:center;">Task Details</h3><br>
  <?php 
  $con=mysqli_connect("localhost","root","","morium");
  $id = mysqli_real_escape_string($con, $_REQUEST['id']);
// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
 $limit = 7;  // Number of entries to show in a page. 
    // Look for a GET variable page if not found default is 1.      
    if (isset($_GET["page"])) {  
      $pn  = $_GET["page"];  
    }  
    else {  
      $pn=1;  
    };   
  
    $start_from = ($pn-1) * $limit;   
  
    $sql = "SELECT * FROM event_task WHERE e_id='$id' ORDER By task_id DESC LIMIT $start_from, $limit ";   
    $rs_result = mysqli_query ($con,$sql); 
echo"<table>
  <tr>
   <th>Task Title</th>
    <th>Member name </th> 
  </tr>";
				 
while($row = mysqli_fetch_array($rs_result)) 
	{ 
        $id=$row['e_id'];
echo "<tr>
         <td>".$row["task_title"]."</td>
		 <td>".$row["m_name"]."</td>
		 </tr>";
			
	}
	echo "</table>";
  ?>
 <ul class="pagination" style="margin-left:100px;"> 
      <?php   
        $sql = "SELECT COUNT(*) FROM event_task WHERE e_id='$id'";   
        $rs_result = mysqli_query($con,$sql);   
        $row = mysqli_fetch_row($rs_result);   
        $total_records = $row[0];   
          
        // Number of pages required. 
        $total_pages = ceil($total_records / $limit);		
        $pagLink = "";                         
        for ($i=1; $i<=$total_pages; $i++) { 
          if ($i==$pn) { 
              $pagLink .= "<li class='active'><a href='view_event_details_insert.php?page="
                                                .$i." & id=".$id."'>".$i."</a></li>"; 
          }             
          else  { 
              $pagLink .= "<li><a href='view_event_details_insert.php?page=".$i."& id=".$id."'> 
                                                ".$i."</a></li>";   
          } 
        }   
        echo $pagLink;   
      ?> 
      </ul> 
</div>
    </div>
   </div>
			
				   
</body>
</html>
