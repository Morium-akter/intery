
<?php

require_once "../config.php";

if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 

$id = mysqli_real_escape_string($link, $_REQUEST['id']);

$sem = mysqli_real_escape_string($link, $_REQUEST['sem']);


$sql = "INSERT into mentor_sem (s_id,semester) VALUES ('$id','$sem')";
   


if(mysqli_query($link, $sql)){
	 header('Location: Mentoring_apply_form.php');
exit;
    
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// close connection
mysqli_close($link);
?>