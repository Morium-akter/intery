<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; }
        .wrapper{ width: 350px; padding: 20px; }
		* {
			  margin: 0;
			}
			.top_head{
				overflow:hidden;
				height:70px;
				background:#128C41;
				text-align: center;
				padding:5px;
				
			}
			.top_child{
				overflow:hidden;
				height:60px;
				background:#333;
			}

			.top_child ul{
				margin-left:0px;
			}

			.top_child ul li{
			float:left;
			padding:17px;
			list-style-type: none;
			}

			.top_child ul li a{
			color:white;
			text-decoration:none;
			padding: 10px;
			}
			.top_child ul li a:hover{
				background:white;
				color:black;
				padding:10px 10px;
			}
			.middle_area
			{
			width:100%;
			overflow:hidden;
			height:500px;
			}
			.row{
            width:100%;
            }


           .column {
           float: left;
           width: 15%;
           padding: 10px;
           height: 500px; 
           }
           .column1 {
		  
           float: left;
           width: 20%;
           padding: 10px;
           height: 500px;
           margin-left:25px;	   
           }
		   .column2 {
		   
           float: left;
           width: 15%;
           padding: 10px;
           height: 500px;
           		   
           }
		   .column3 {
		   
           float: left;
           width: 48%;
           padding: 10px;
           height: 500px;
           		   
           }
		    table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #B3CBD2;;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
				
    </style>
</head>
<body>
<div class="top_head">
		  <h1>IUBAT IT society management system</h1>
		</div>
		<div class="top_child">
			<ul>
				<li><a href="../after_admin_login_home.php">Home</a></li>
				<li><a href="">Notice</a></li>
				<li><a href="loantype.html">Mentoring Class</a></li>
				<li><a href="#">Member</a></li>
				<li><a href="#">Event</a></li>
				<li><a href="#">Finance</a></li>
				<li><a href="../logout.php">Logout</a></li>
			</ul>
		</div>

<div class="row">
  <div class="column1" style="background-color:#bbb;">
			   <h2><?php
$con=mysqli_connect("localhost","root","","morium");
// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
				 
$result = mysqli_query($con,"SELECT status FROM configur  WHERE id='1'");
          
	while ($row = $result->fetch_assoc()) {
    $a= $row['status'];
}
	if($a=='1'){
		echo "Now Apply section is blocked";?>
		<form action="Apply_Section_insert.php" method="post" >
			<input type="hidden" value="0" name="id">
			<input type="submit" value="Start">
            </form>
			<?php
	}
	else{
		echo "Now Apply section is opened";
		?>
		<form action="Apply_Section_insert.php" method="post" >
			<input type="hidden" value="1" name="id">
			<input type="submit" value="Stop">
            </form>
			<?php
	}

mysqli_close($con);
?> </h2></br></br>
        
    </div>
	<div class="column" style="background-color:#B3CBD2;"><h3> Selete Semester for mentoring </h3><br>
  <div>
  <?php
$con=mysqli_connect("localhost","root","","morium");
// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
//print_r($_REQUEST);
$result = mysqli_query($con,"SELECT  id, semester FROM semester  WHERE NOT EXISTS (SELECT NULL FROM mentor_sem WHERE semester.id = mentor_sem.s_id) ORDER By id DESC   ");
				 
while($row = mysqli_fetch_array($result)) 
	{ 
		$c=$row['id']  ;
            $a=$row['semester'];
            
			?>
			<form action="Mentor_semester_insert.php" method="post" >
			<input type="hidden" value="<?php echo $row['id']; ?>" name="id">
			<input type="hidden" value="<?php echo $row['semester']; ?>" name="sem">
			<input type="submit" value="<?php echo $row['semester']?>">
            </form>
           
			<?php
				  
	}
	
	?>		
  	</div>
</div>
<div class="column2" style="background-color:#bbb;"><h3>Offered semester</h3><br>
  

	<div>
 <?php
$con=mysqli_connect("localhost","root","","morium");
// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

//$id = mysqli_real_escape_string($con, $_REQUEST['id']);
//echo $id;
$sql="SELECT * FROM mentor_sem ";
$result = mysqli_query($con,$sql);
				 
while($row = mysqli_fetch_array($result)) 
	{ 
		
            $a=$row['s_id']; 
			$b=$row['semester']; 
			echo $b;
			echo "   ";
			?>
			<a href="Mentor_semester_delete.php?id=<?php echo $row['semester']?>">Delete</a><br>
			<?php
	}
	?>

		</div> 
			
		</div>
		<div class="column3" style="background-color:#B3CBD2;"><h3> Semester</h3><br>
  <div>
  <?php
$con=mysqli_connect("localhost","root","","morium");
// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
$sql="SELECT * FROM mentor_sem ";
$result1 = mysqli_query($con,$sql);
				 
while($row = mysqli_fetch_array($result1)) 
	{ 
		$a=$row['s_id']; 
	    $b=$row['semester']; 
		
	}
	$s_id=$a;
//print_r($_REQUEST);
$result = mysqli_query($con,"SELECT id,ID_no,username,email,phone_number,Course_Code FROM mentor_apply WHERE (s_id='$s_id' AND status='0') ");
echo"<table>
  <tr>
    <th>ID</th>
    <th>User Name</th>
    <th>Email</th>
    <th>Phone Number</th>
    <th>Course Code</th>	
  </tr>";
				 
while($row = mysqli_fetch_array($result)) 
	{ 
        $idno=$row['id'];
		echo "<tr>
		
         <td>".$row["ID_no"]."</td>
         <td>".$row["username"]."</td>
		 <td>".$row["email"]."</td>
         <td>".$row["phone_number"]."</td>
		 <td>".$row["Course_Code"]."</td>"
		 
            
			?>
			<td><a href="Mentor_select_form.php?id=<?php echo $row['id']?>">Select</a></td>
			<td><a href="Mentor_delete.php?id=<?php echo $row['id']?>">Delete</a></td>
           
			<?php		  
	}
	echo "</tr>";
	echo "</table>";
	?>		
  	</div>
</div>
</div>		
</body>
</html>
