

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; }
        .wrapper{ width: 350px; padding: 20px; }
		* {
			  margin: 0;
			}
			.top_head{
				overflow:hidden;
				height:70px;
				background:#128C41;
				text-align: center;
				padding:5px;
				
			}
			.top_child{
				overflow:hidden;
				height:60px;
				background:#333;
			}

			.top_child ul{
				margin-left:0px;
			}

			.top_child ul li{
			float:left;
			padding:17px;
			list-style-type: none;
			}

			.top_child ul li a{
			color:white;
			text-decoration:none;
			padding: 10px;
			}
			.top_child ul li a:hover{
				background:white;
				color:black;
				padding:10px 10px;
			}
			.middle_area
			{
			background-color:#B3CBD2;
			width:100%;
			overflow:hidden;
			height:500px;
			
			}
						
				.row{
            width:100%;
            }


           .column {
           float: left;
           width: 40%;
           padding: 10px;
           height: 500px; 
           }
           .column1 {
		   margin-left:50px;
           float: left;
           width: 50%;
           padding: 10px;
           height: 500px;
           margin-left:50px;		   
           }
		   table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #B3CBD2;;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
    </style>
</head>
<body>
<div class="top_head">
		  <h1>IUBAT IT society management system</h1>
		</div>
		<div class="top_child">
			<ul>
				<li><a href="../after_user_login_home.php">Home</a></li>
				<li><a href="">Notice</a></li>
				<li><a href="">Mentoring Class</a></li>
				<li><a href="#">Member</a></li>
				<li><a href="#">Event</a></li>
				<li><a href="../logout.php">Logout</a></li>
			</ul>
		</div>
		<div class="middle_area">
		
<div class="row">
  <div class="colum" style="background-color:#bbb; text-align:center;"><h3>Select semester Name </h3>
 

<form action="view_mentoring_routine_insert_user.php" method="post">
  
  <label for="semester">Semester:</label><br>
  <select name="semester" class="">
  <option value="" ></option>
<?php
$con=mysqli_connect("localhost","root","","morium");

$sql = mysqli_query($con, "SELECT id, semester FROM semester ORDER BY id DESC ");
$row = mysqli_num_rows($sql);
while ($row = mysqli_fetch_array($sql)){
echo "<option value='". $row['semester'] ."'>" .$row['semester'] ."</option>" ;
}
?>
</select>
  <input type="submit" value="Submit">
</form>
			 		 
  </div>
  			   
</body>
</html>
