<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "", "morium");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
$sem = mysqli_real_escape_string($link, $_REQUEST['id']);

// Attempt delete query execution
$sql = "DELETE FROM mentor_sem WHERE semester='$sem'";
if(mysqli_query($link, $sql)){
    include("Mentoring_apply_form.php");
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>
