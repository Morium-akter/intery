
<?php

require_once "../config.php";

if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
$course_code = mysqli_real_escape_string($link, $_REQUEST['courseID']);
$id = mysqli_real_escape_string($link, $_REQUEST['id']);
$c = mysqli_real_escape_string($link, $_REQUEST['c']);

$sql = "INSERT into mentoring (course_code,s_id,course_id) VALUES ('$course_code','$id','$c')";
   


if(mysqli_query($link, $sql)){
	
    include("Mentor_course_offer.php");
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// close connection
mysqli_close($link);
?>