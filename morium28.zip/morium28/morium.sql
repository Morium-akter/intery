-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 29, 2020 at 09:21 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `morium`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_amount`
--

CREATE TABLE `add_amount` (
  `a_id` int(255) NOT NULL,
  `name` varchar(50) NOT NULL,
  `purpose` varchar(100) NOT NULL,
  `amount` int(15) NOT NULL,
  `date` date NOT NULL,
  `status` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `add_amount`
--

INSERT INTO `add_amount` (`a_id`, `name`, `purpose`, `amount`, `date`, `status`) VALUES
(1, 'Prof.Dr.kaykubad', 'programming', 0, '2020-03-28', 1),
(2, 'Prof.Dr.kaykukab', 'Math olympic', 2000, '2020-03-27', 1),
(3, 'Morium Akter', 'culture', 1000, '2020-03-29', 1),
(4, 'Prof.dr.Shamim akhter', 'seminar', 500, '2020-03-29', 2);

-- --------------------------------------------------------

--
-- Table structure for table `configur`
--

CREATE TABLE `configur` (
  `id` int(255) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `configur`
--

INSERT INTO `configur` (`id`, `status`) VALUES
(1, 0),
(2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `coordinator`
--

CREATE TABLE `coordinator` (
  `id` int(255) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone_number` int(15) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `coordinator`
--

INSERT INTO `coordinator` (`id`, `username`, `email`, `phone_number`, `password`) VALUES
(5, 'Dr. utpal kanti das', 'dr.utpalkantidas@gmail.com', 1758362733, '$2y$10$DsfGOAHck0t0/s9xvZ6URO8qBRHQ8J8g3JZqAwlA3SMB7JT.zmA/K');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `id` int(255) NOT NULL,
  `course_code` varchar(30) NOT NULL,
  `course_name` varchar(50) NOT NULL,
  `credit` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`id`, `course_code`, `course_name`, `credit`) VALUES
(1, 'csc102', 'fundamental', 3),
(2, 'csc103', 'fundamental lab', 1),
(3, 'csc183', 'programming C', 3),
(4, 'csc184', 'programming C lab', 1),
(7, 'csc197', 'Assembly language', 3),
(8, 'csc231', 'Fundamental of Electronics and Digital Systems', 3),
(9, 'csc232', 'Electronics and digital lab', 1),
(10, 'csc247', 'Computer  Architecture', 3),
(12, 'csc284', 'Programming  lab C++', 1),
(13, 'csc283', 'Programming C++', 3),
(14, 'csc307', 'Operating system', 3);

-- --------------------------------------------------------

--
-- Table structure for table `date`
--

CREATE TABLE `date` (
  `id` int(255) NOT NULL,
  `e_id` int(255) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `date`
--

INSERT INTO `date` (`id`, `e_id`, `date`) VALUES
(3, 2, '2020-03-28'),
(4, 5, '2020-03-28'),
(5, 5, '2020-03-28');

-- --------------------------------------------------------

--
-- Table structure for table `deduct_amount`
--

CREATE TABLE `deduct_amount` (
  `d_id` int(255) NOT NULL,
  `e_id` int(255) NOT NULL,
  `name` varchar(50) NOT NULL,
  `purpose` varchar(100) NOT NULL,
  `amount` int(15) NOT NULL,
  `totalamount` int(15) NOT NULL,
  `date` date NOT NULL,
  `status` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `deduct_amount`
--

INSERT INTO `deduct_amount` (`d_id`, `e_id`, `name`, `purpose`, `amount`, `totalamount`, `date`, `status`) VALUES
(6, 5, 'Sumaya  Ahmed Lorin', 'monitor', 400, 700, '2020-03-28', 0),
(9, 5, 'soma sarkar', 't_shirt', 300, 700, '2020-03-28', 0),
(10, 1, 'soma', 't-shirt', 1000, 1500, '2020-03-28', 1),
(11, 1, 'Morium Akter', 'decoretion', 500, 1500, '2020-03-28', 1);

-- --------------------------------------------------------

--
-- Table structure for table `designation`
--

CREATE TABLE `designation` (
  `id` int(255) NOT NULL,
  `designation` varchar(50) NOT NULL,
  `dpt` varchar(50) NOT NULL,
  `status` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `designation`
--

INSERT INTO `designation` (`id`, `designation`, `dpt`, `status`) VALUES
(5, 'Manager', 'education', 0),
(6, 'Assistant Manager', 'education', 1),
(7, 'Depoti manager', 'education', 1),
(8, 'Assistant Manager', 'programming', 1),
(9, 'Manager', 'programming', 1),
(10, 'Depoti manager', 'programming', 0);

-- --------------------------------------------------------

--
-- Table structure for table `event_task`
--

CREATE TABLE `event_task` (
  `task_id` int(255) NOT NULL,
  `e_id` int(255) NOT NULL,
  `task_title` varchar(100) NOT NULL,
  `m_name` varchar(50) NOT NULL,
  `amount` int(15) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `event_task`
--

INSERT INTO `event_task` (`task_id`, `e_id`, `task_title`, `m_name`, `amount`, `date`) VALUES
(1, 1, 'Fodd', 'Morium Akter', 0, '0000-00-00'),
(2, 0, 'Food', 'Morium Akter', 0, '0000-00-00'),
(3, 1, 'Food', 'Morium Akter', 0, '0000-00-00'),
(4, 1, 'Food', 'Morium Akter', 0, '0000-00-00'),
(5, 1, 'Food', 'Morium Akter', 0, '0000-00-00'),
(6, 1, 'Food', 'Morium Akter', 0, '0000-00-00'),
(7, 1, 'Food', 'Morium Akter', 0, '0000-00-00'),
(8, 0, 'Food', 'Morium Akter', 0, '0000-00-00'),
(9, 1, 'Food', 'Morium Akter', 0, '0000-00-00'),
(10, 0, 'Food', 'Morium Akter', 0, '0000-00-00'),
(11, 0, 'Food', 'Morium Akter', 0, '0000-00-00'),
(12, 0, 'Food', 'Morium Akter', 0, '0000-00-00'),
(13, 0, 'Food', 'Morium Akter', 0, '0000-00-00'),
(14, 1, 'Food', 'Morium Akter', 0, '0000-00-00'),
(15, 1, 'decoretion', 'Morium Akter', 500, '0000-00-00'),
(16, 1, 't-shirt', 'soma', 1000, '0000-00-00'),
(17, 2, 'Food', 'soma sarkar', 500, '0000-00-00'),
(18, 2, 't_shirt', 'Sumaya  Ahmed Lorin', 900, '0000-00-00'),
(21, 5, 't_shirt', 'soma sarkar', 300, '2020-03-28'),
(22, 5, 'monitor', 'Sumaya  Ahmed Lorin', 400, '2020-03-28');

-- --------------------------------------------------------

--
-- Table structure for table `event_title`
--

CREATE TABLE `event_title` (
  `e_id` int(255) NOT NULL,
  `event_title` varchar(100) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `event_title`
--

INSERT INTO `event_title` (`e_id`, `event_title`, `date`) VALUES
(1, 'programming contest spring 2017', '0000-00-00'),
(5, 'equipment', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `file`
--

CREATE TABLE `file` (
  `file_id` int(255) NOT NULL,
  `name` varchar(200) NOT NULL,
  `N_id` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `file`
--

INSERT INTO `file` (`file_id`, `name`, `N_id`) VALUES
(1, 'logo.jpg', 39),
(7, '20200316151107_IMG_8626 - Copy.JPG', 40),
(8, '20200316151549_IMG_8634.JPG', 41),
(9, '20200316145147_IMG_8563.JPG', 42),
(10, '20200316144208_IMG_8529.JPG', 42),
(11, '20200316144208_IMG_8529.JPG', 42),
(12, '', 42),
(13, '20200316151542_IMG_8633.JPG', 42),
(14, '', 42),
(15, '20200316144208_IMG_8529.JPG', 42),
(16, '20200316151542_IMG_8633.JPG', 42),
(17, '79851200_1184257351778574_3697502096329801728_o (1).jpg', 42),
(18, '80451256_1184257551778554_5093234204011921408_o.jpg', 42),
(19, '79851200_1184257351778574_3697502096329801728_o (1).jpg', 1),
(20, '80451256_1184257551778554_5093234204011921408_o.jpg', 1),
(21, '011148569-e6aadf99-06a8-4c22-89c2-6ed4d419bd8f.jpg', 2),
(22, 'football-live-streaming-beoutq-premier-league.jpg', 2),
(23, 'images1.jpg', 2),
(24, '011148569-e6aadf99-06a8-4c22-89c2-6ed4d419bd8f.jpg', 2),
(25, 'football-live-streaming-beoutq-premier-league.jpg', 2),
(26, 'images1.jpg', 2),
(27, '011148569-e6aadf99-06a8-4c22-89c2-6ed4d419bd8f.jpg', 42),
(28, 'football-live-streaming-beoutq-premier-league.jpg', 42),
(29, 'images1.jpg', 42),
(30, '011148569-e6aadf99-06a8-4c22-89c2-6ed4d419bd8f.jpg', 43),
(31, 'football-live-streaming-beoutq-premier-league.jpg', 43),
(32, 'mentoring.jpg', 44),
(33, 'iubat.jpg', 44),
(34, '80042711_1184257468445229_6520705742054359040_o.jpg', 44),
(35, '79851200_1184257351778574_3697502096329801728_o.jpg', 44),
(36, '20200316151606_IMG_8635.JPG', 45),
(37, '20200316151542_IMG_8633-01.jpeg', 45);

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE `member` (
  `id` int(255) NOT NULL,
  `ID_no` int(10) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `phone_number` varchar(15) NOT NULL,
  `cgpa` varchar(5) NOT NULL,
  `designation` varchar(30) NOT NULL,
  `dpt` varchar(30) NOT NULL,
  `status` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`id`, `ID_no`, `username`, `email`, `phone_number`, `cgpa`, `designation`, `dpt`, `status`) VALUES
(4, 16203021, 'soma sarkar', 'somasarkar@gmail.com', '01747423402', '', 'Assistant Manager', 'education', 1),
(5, 16203095, 'Sumaya  Ahmed Lorin', 'lorinahmed@gmail.com', '01689813593', '3.50', 'Manager', 'programming', 1);

-- --------------------------------------------------------

--
-- Table structure for table `mentoring`
--

CREATE TABLE `mentoring` (
  `id` int(255) NOT NULL,
  `course_code` varchar(30) NOT NULL,
  `s_id` varchar(30) NOT NULL,
  `course_id` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mentoring`
--

INSERT INTO `mentoring` (`id`, `course_code`, `s_id`, `course_id`) VALUES
(17, 'csc102', '1', '1'),
(19, 'csc103', '20', '2'),
(20, 'csc183', '20', '3');

-- --------------------------------------------------------

--
-- Table structure for table `mentor_apply`
--

CREATE TABLE `mentor_apply` (
  `id` int(255) NOT NULL,
  `ID_no` int(10) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `phone_number` varchar(15) NOT NULL,
  `semester` varchar(10) NOT NULL,
  `cgpa` varchar(5) NOT NULL,
  `Course_Code` varchar(10) NOT NULL,
  `s_id` int(255) NOT NULL,
  `status` int(4) NOT NULL,
  `room` varchar(30) NOT NULL,
  `starttime` varchar(30) NOT NULL,
  `endtime` varchar(30) NOT NULL,
  `day` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mentor_apply`
--

INSERT INTO `mentor_apply` (`id`, `ID_no`, `username`, `email`, `phone_number`, `semester`, `cgpa`, `Course_Code`, `s_id`, `status`, `room`, `starttime`, `endtime`, `day`) VALUES
(9, 16203057, 'Morium Akter', 'tamannamorium57@gmai', '01758463733', '', '3.90', 'csc183', 20, 1, '310', '2.00 PM - 3.00PM', '', 'sunday'),
(10, 16203095, 'Sumaya  Ahmed Lorin', 'lorinahmed@gmail.com', '01689813593', 'eleven', '3.30', 'csc183', 20, 1, '310', '', '16:20', 'Tuesday');

-- --------------------------------------------------------

--
-- Table structure for table `mentor_sem`
--

CREATE TABLE `mentor_sem` (
  `id` int(255) NOT NULL,
  `s_id` int(10) NOT NULL,
  `semester` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `notice`
--

CREATE TABLE `notice` (
  `id` int(255) NOT NULL,
  `User_name` varchar(50) NOT NULL,
  `n_title` varchar(100) NOT NULL,
  `n_des` varchar(10000) NOT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `image` varchar(255) NOT NULL,
  `uploaded_on` datetime(6) NOT NULL,
  `Status` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `notice`
--

INSERT INTO `notice` (`id`, `User_name`, `n_title`, `n_des`, `file_name`, `image`, `uploaded_on`, `Status`) VALUES
(1, 'morium', 'mmm', '', '', '', '2020-02-23 09:54:56.000000', 1),
(8, 'morium', 'naaa', 'bolol', '', '', '2020-02-25 12:03:07.000000', 1),
(10, 'morium', '', '', '', '', '2020-03-01 10:45:21.000000', 1),
(13, 'Sajid', 'mentoring', 'oooooooo', '', '', '2020-03-02 15:30:28.000000', 1),
(14, 'morium', 'bol', 'naaaa', '', '', '2020-03-03 12:54:48.000000', 1),
(18, 'Morium Akter', 'nnnn', 'na', '', '', '2020-03-03 13:55:19.000000', 0),
(19, 'morium', 'meeting', '9 A.M', '', '', '2020-03-04 22:38:38.000000', 1),
(20, 'morium', 'mentor', '10', '', '', '2020-03-04 22:40:00.000000', 1),
(21, 'morium', 'programming', 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', '', '', '2020-03-23 13:13:59.000000', 1),
(22, 'morium', 'programming', 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', '', '', '2020-03-23 13:14:55.000000', 1),
(23, 'morium', 'Mentoring class', 'oooooooooooooooooooooooooooooooooooooooooo', '20200316151542_IMG_8633-01.jpeg', '', '2020-03-23 19:34:50.000000', 1),
(24, 'morium', '', '', '', '', '2020-03-23 21:20:45.000000', 1),
(25, 'morium', 'bol', 'mmmmmmmmmmmmmmmmmmmmmmmm', '', '', '2020-03-24 00:02:27.000000', 1),
(26, 'morium', 'ppp', '', '', '', '2020-03-24 00:10:07.000000', 1),
(27, 'morium', 'nnnn', '', '', '', '2020-03-24 00:11:33.000000', 1),
(28, 'morium', 'bbbb', '', '', '20200316151606_IMG_8635.JPG', '2020-03-24 00:13:03.000000', 1),
(29, 'morium', 'vvvvv', 'ssssssssssssssssssssssssss', '', '', '2020-03-25 20:08:45.000000', 1),
(30, 'morium', 'vv', 'sssss', '', '', '2020-03-25 20:09:52.000000', 1),
(31, 'morium', 'vv', 'sssss', '', '', '2020-03-25 20:10:49.000000', 1),
(32, 'morium', 'vv', 'sssss', '', '', '2020-03-25 20:18:32.000000', 1),
(33, 'morium', 'vv', 'sssss', '', '', '2020-03-25 20:19:45.000000', 1),
(34, 'morium', 'ww', 'zzzz', '', '', '2020-03-25 20:20:19.000000', 1),
(35, 'morium', 'zzz', 'yyy', '', '', '2020-03-25 20:26:11.000000', 1),
(36, 'morium', 'zzz', 'aaaa', '', '', '2020-03-25 21:06:12.000000', 1),
(37, 'morium', 'xxx', 'yyyy', NULL, '', '2020-03-25 21:07:00.000000', 1),
(38, 'morium', 'xxx', 'yyyy', NULL, '', '2020-03-25 21:07:51.000000', 1),
(40, 'morium', 'bol', 'na', NULL, '', '2020-03-25 22:16:06.000000', 1),
(41, 'morium', 'bol', 'na', NULL, '', '2020-03-25 22:18:31.000000', 1),
(44, 'soma sarkar', 'bol', 'na', NULL, '', '2020-03-25 22:47:53.000000', 0),
(45, 'soma sarkar', 'bol', '', NULL, '', '2020-03-25 22:54:36.000000', 1);

-- --------------------------------------------------------

--
-- Table structure for table `offer_course`
--

CREATE TABLE `offer_course` (
  `id` int(11) NOT NULL,
  `s_id` int(255) NOT NULL,
  `course_id` int(11) DEFAULT NULL,
  `course_code` varchar(50) NOT NULL,
  `status` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `offer_course`
--

INSERT INTO `offer_course` (`id`, `s_id`, `course_id`, `course_code`, `status`) VALUES
(35, 1, 1, 'csc102', ''),
(36, 1, 2, 'csc103', ''),
(38, 20, 1, 'csc102', ''),
(39, 20, 3, 'csc183', ''),
(40, 20, 4, 'csc184', ''),
(41, 20, 7, 'csc197', ''),
(43, 20, 2, 'csc103', '');

-- --------------------------------------------------------

--
-- Table structure for table `semester`
--

CREATE TABLE `semester` (
  `id` int(255) NOT NULL,
  `semester` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `semester`
--

INSERT INTO `semester` (`id`, `semester`) VALUES
(17, 'spring2019'),
(18, 'summer2019'),
(19, 'fall2019'),
(20, 'spring2020');

-- --------------------------------------------------------

--
-- Table structure for table `s_user`
--

CREATE TABLE `s_user` (
  `id` bigint(255) NOT NULL,
  `ID_no` varchar(10) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(20) NOT NULL,
  `phone_number` varchar(15) NOT NULL,
  `usertype` varchar(20) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `s_user`
--

INSERT INTO `s_user` (`id`, `ID_no`, `username`, `email`, `phone_number`, `usertype`, `password`) VALUES
(5, '16203095', 'Sumaya  Ahmed Lorin', 'lorinahmed@gmail.com', '01689813593', '', '$2y$10$O.AFf2GLi3HXBxMCyIZ2BeWNqsiKhgbo8w8qi//GuU5r6HSQpXzwq'),
(7, '16203021', 'soma sarkar', 'somasarkar@gmail.com', '01747423402', 'student', '$2y$10$kowLdO3qDpn21Eyg9epuLONALpJyqS61JX5PMKikWuUwsgq4q.zyi');

-- --------------------------------------------------------

--
-- Table structure for table `transection`
--

CREATE TABLE `transection` (
  `t_id` int(255) NOT NULL,
  `a_id` int(255) NOT NULL,
  `d_id` int(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `amount` int(15) NOT NULL,
  `Total_amount` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transection`
--

INSERT INTO `transection` (`t_id`, `a_id`, `d_id`, `type`, `amount`, `Total_amount`) VALUES
(1, 2, 0, 'add', 2000, 2000),
(8, 3, 0, 'add', 1000, 3000),
(15, 0, 1, 'deduct', 1500, 1500);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(50) NOT NULL,
  `username` varchar(30) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `email` varchar(30) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `phone_number` varchar(15) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `password` varchar(255) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `phone_number`, `password`) VALUES
(5, 'morium', 'tamannamorium@gmail.com', '01912242247', '$2y$10$RorPjbiea3Hr9wV9puJLgOei8vJQS11uTvbbZOIxTQ3UmqfJfAur6'),
(6, 'eaty', 'tamannamorium57@gmail.com', '01758462733', '$2y$10$g7o1ZGt4KA9DWa.rOsNa.u8x7yO5KA1s2DUj4W/bpyDSM8r8kdSdq');

-- --------------------------------------------------------

--
-- Table structure for table `u_notice`
--

CREATE TABLE `u_notice` (
  `id` int(255) NOT NULL,
  `User_Name` varchar(50) NOT NULL,
  `n_title` varchar(100) NOT NULL,
  `n_des` varchar(1000) NOT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `uploaded_on` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `u_notice`
--

INSERT INTO `u_notice` (`id`, `User_Name`, `n_title`, `n_des`, `file_name`, `uploaded_on`) VALUES
(1, 'morium', 'bol', 'na', '', '2020-02-24 00:51:19.000000');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_amount`
--
ALTER TABLE `add_amount`
  ADD PRIMARY KEY (`a_id`);

--
-- Indexes for table `configur`
--
ALTER TABLE `configur`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coordinator`
--
ALTER TABLE `coordinator`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `date`
--
ALTER TABLE `date`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `deduct_amount`
--
ALTER TABLE `deduct_amount`
  ADD PRIMARY KEY (`d_id`);

--
-- Indexes for table `designation`
--
ALTER TABLE `designation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `event_task`
--
ALTER TABLE `event_task`
  ADD PRIMARY KEY (`task_id`);

--
-- Indexes for table `event_title`
--
ALTER TABLE `event_title`
  ADD PRIMARY KEY (`e_id`);

--
-- Indexes for table `file`
--
ALTER TABLE `file`
  ADD PRIMARY KEY (`file_id`);

--
-- Indexes for table `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mentoring`
--
ALTER TABLE `mentoring`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mentor_apply`
--
ALTER TABLE `mentor_apply`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notice`
--
ALTER TABLE `notice`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `offer_course`
--
ALTER TABLE `offer_course`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `semester`
--
ALTER TABLE `semester`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `s_user`
--
ALTER TABLE `s_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transection`
--
ALTER TABLE `transection`
  ADD PRIMARY KEY (`t_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `u_notice`
--
ALTER TABLE `u_notice`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_amount`
--
ALTER TABLE `add_amount`
  MODIFY `a_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `configur`
--
ALTER TABLE `configur`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `coordinator`
--
ALTER TABLE `coordinator`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `date`
--
ALTER TABLE `date`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `deduct_amount`
--
ALTER TABLE `deduct_amount`
  MODIFY `d_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `designation`
--
ALTER TABLE `designation`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `event_task`
--
ALTER TABLE `event_task`
  MODIFY `task_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `event_title`
--
ALTER TABLE `event_title`
  MODIFY `e_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `file`
--
ALTER TABLE `file`
  MODIFY `file_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `member`
--
ALTER TABLE `member`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `mentoring`
--
ALTER TABLE `mentoring`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `mentor_apply`
--
ALTER TABLE `mentor_apply`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `notice`
--
ALTER TABLE `notice`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `offer_course`
--
ALTER TABLE `offer_course`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `semester`
--
ALTER TABLE `semester`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `s_user`
--
ALTER TABLE `s_user`
  MODIFY `id` bigint(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `transection`
--
ALTER TABLE `transection`
  MODIFY `t_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `u_notice`
--
ALTER TABLE `u_notice`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
