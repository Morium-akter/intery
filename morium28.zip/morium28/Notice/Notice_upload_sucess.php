

<!DOCTYPE html>
<!-- saved from url=(0048)file:///C:/Users/Student/Desktop/Test/index.html -->
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
		<title>
		Home
		</title>
		<style>
			* {
			  margin: 0;
			}
			.top_head{
				overflow:hidden;
				height:40px;
				background:#128C41;
				text-align: center;
				padding:17px;
				
			}
			.top_child{
				overflow:hidden;
				height:60px;
				background:#333;
			}

			.top_child ul{
				margin-left:0px;
			}

			.top_child ul li{
			float:left;
			padding:17px;
			list-style-type: none;
			}

			.top_child ul li a{
			color:white;
			text-decoration:none;
			padding: 10px;
			}
			
			.top_child ul li a:hover{
				background:white;
				color:black;
				padding:10px 10px;}
		    .dropdown {
  float: left;
  overflow: hidden;
}

.dropdown .dropbtn {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.navbar a:hover, .dropdown:hover .dropbtn {
  background-color: white;
  color:black;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 120px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  float: none;
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
  background-color: #ddd;
}

.dropdown:hover .dropdown-content {
  display: block;
}


			.middle_area
			{
			width:100%;
			overflow:hidden;
			height:500px;
			}

			footer {
			text-align:center;
			background:#777;
			heigth:60px;
		  padding: 10px;
			}
			img {
				width: 100%;
				height: auto;
			}
		</style>
	</head>
	<body>

		<!-- Top Area -->
		<div class="top_head">
		  <h1>IUBAT IT society</h1>
		</div>
		<div class="top_child">
			<ul>
				<li><a href="../after_admin_login_home.php">Home</a></li>
				<div class="dropdown">
    <button class="dropbtn">Notice 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="Notice/Notice_form.php">Upload Notice</a>
      <a href="Notice/Notice_view.php">View Notice</a>
     <a href="Notice/Notice_request_view_ad.php">Requesting Notice</a>
    </div>
  </div> 
            <div class="dropdown">
    <button class="dropbtn">Course 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="Course/Course_semester_form.php">Offer Course</a>
      <a href="Course/View_offered_course_form.php">View Offered Course</a>
     
    </div>
  </div>
				<div class="dropdown">
    <button class="dropbtn">MentoringClass 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="Mentoring/Mentoringclass_course_form.php">Mentoring Course</a>
      <a href="Mentoring/view_mentoring_routine_form.php">View Routine</a>
     <a href="Mentoring/Mentoring_apply_form.php">Apply</a>
    </div>
  </div> 
                <div class="dropdown">
    <button class="dropbtn">Member 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="Member/Member_details_admin.php">Member Details</a>
      <a href="Member/Member_apply_form.php">Apply</a>
    </div>
  </div>
				
				<div class="dropdown">
    <button class="dropbtn">Event 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="Event/New_Event_form.php">New Event</a>
      <a href="Event/View_event_details.php">Details</a>
    </div>
  </div>
				<div class="dropdown">
    <button class="dropbtn">Fund 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="Fund/Add_form.php">Add</a>
      <a href="Mentoring/view_mentoring_routine_form.php">deduct</a>
     <a href="Mentoring/Mentoring_apply_form.php">Show fund</a>
    </div>
  </div> 
				
				<div class="dropdown">
    <button class="dropbtn">Admin 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="registrar.php">Add Admin</a>
      
    </div>
  </div> 
		
				<li><a href="logout.php">Logout</a></li>
			</ul>
		</div>

		<div class="middle_area">
			<h1 style="text-align:center;">Notice Upload successfully</h1>
			</div>

		
</body>
</html>
