<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; }
        .wrapper{ width: 350px; padding: 20px; }
		* {
			  margin: 0;
			}
			.top_head{
				overflow:hidden;
				height:70px;
				background:#128C41;
				text-align: center;
				padding:5px;
				
			}
			.top_child{
				overflow:hidden;
				height:60px;
				background:#333;
			}

			.top_child ul{
				margin-left:0px;
			}

			.top_child ul li{
			float:left;
			padding:17px;
			list-style-type: none;
			}

			.top_child ul li a{
			color:white;
			text-decoration:none;
			padding: 10px;
			}
			.top_child ul li a:hover{
				background:white;
				color:black;
				padding:10px 10px;
			.middle_area
			{
			width:100%;
			overflow:hidden;
			height:500px;
			}	
				}
    </style>
</head>
<body>
<div class="top_head">
		  <h1>IUBAT IT society management system</h1>
		</div>
		<div class="top_child">
			<ul>
				<li><a href="after_admin_login_home.php">Home</a></li>
				<li><a href="">Notice</a></li>
				<li><a href="loantype.html">Mentoring Class</a></li>
				<li><a href="#">Member</a></li>
				<li><a href="#">Event</a></li>
				<li><a href="#">Finance</a></li>
				<li><a href="logout.php">Logout</a></li>
			</ul>
		</div>
<div class="middle_area">
		
		 <div class="row">
		   
			    <div class="col-md-4">
			     </div>
			   <div class="col-md-4"></br></br>
			   
			   <h2>Upload Notice</h2></br></br>
        <form action="Notice_edit_code.php" method="post">
		<p>
        <label for="id">Notice ID</label>
        <input type="text" name="id" id="id">
    </p>
    <p>
        <label for="n_title">Notice Title</label>
        <input type="text" name="n_title" id="n_title">
    </p>
    <p>
       <label for="n_des">Notice description</label>
        <input type="text" name="n_des" id="n_des">
    </p>
    <p>
	<label for="file_name">File/Image</label>
        <input type="file" name="file_name">
    
    </p>
	 	
	<!--<p>
        <label for="User_name">User_name</label>
        <input type="text" name="User_name" id="User_name">
    </p>-->
    <input type="submit" value="Submit">
</form>
    </div>
	 <div class="col-md-4">
	</div>
			
				   
</body>
</html>
