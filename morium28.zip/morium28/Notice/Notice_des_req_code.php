<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; }
        .wrapper{ width: 350px; padding: 20px; }
		* {
			  margin: 0;
			}
			.top_head{
				overflow:hidden;
				height:70px;
				background:#128C41;
				text-align: center;
				padding:5px;
				
			}
			.top_child{
				overflow:hidden;
				height:60px;
				background:#333;
			}

			.top_child ul{
				margin-left:0px;
			}

			.top_child ul li{
			float:left;
			padding:17px;
			list-style-type: none;
			}

			.top_child ul li a{
			color:white;
			text-decoration:none;
			padding: 10px;
			}
			.top_child ul li a:hover{
				background:white;
				color:black;
				padding:10px 10px;
			}
			.middle_area
			{	
			background-color:#B3CBD2;
			width:100%;
			overflow:hidden;
			height:500px;
			}
			.row
			{	
			background-color:#B3CBD2;
			width:100%;
			overflow:hidden;
			height:500px;
			}
			
	
    </style>
</head>
<body>
<div class="top_head">
		  <h1>IUBAT IT society management system</h1>
		</div>
		<div class="top_child">
			<ul>
				<li><a href="../after_admin_login_home.php">Home</a></li>
				<li><a href="">Notice</a></li>
				<li><a href="loantype.html">Mentoring Class</a></li>
				<li><a href="#">Member</a></li>
				<li><a href="#">Event</a></li>
				<li><a href="#">Finance</a></li>
				<li><a href="../logout.php">Logout</a></li>
			</ul>
		</div>
<div class="middle_area">
		 <div class="row">
		   
			    <div class="col-md-4">
			     </div>
			   <div class="col-md-4"></br>
		
			   
			   <h2>Notice Decription and File</h2>
<?php
$con=mysqli_connect("localhost","root","","morium");
// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
$id = mysqli_real_escape_string($con, $_REQUEST['id']);
$result = mysqli_query($con,"SELECT  n_des FROM notice WHERE 	id='$id'");

while($row = mysqli_fetch_array($result)) 
	{
            $a=$row['n_des'] ;
		echo $a;?><br><br><?php	
	}
	
$result = mysqli_query($con,"SELECT  name FROM file WHERE 	N_id='$id'");

while($row = mysqli_fetch_array($result)) 
	{
           $image= $row['name'];
		 $image_src = "upload/".$image;
		  echo "<img src='$image_src' ,height='120px', width='120px' >";	
	}

mysqli_close($con);
?> 
</br></br><a href='Notice_request_view_ad.php' >Back</a>

    </div>
	 <div class="col-md-4">
	</div>
			
				   
</body>
</html>
