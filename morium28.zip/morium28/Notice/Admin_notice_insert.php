<?php session_start();
//var_dump($_SESSION);
$email=$_SESSION['email'];
$ID=$_SESSION['id'];
$con=mysqli_connect("localhost","root","","morium");
$result = mysqli_query($con,"SELECT  username FROM users  WHERE id='$ID' ");
while ($row = $result->fetch_assoc()) {
    $a= $row['username'];
}
?>

<?php
require_once "../config.php";

if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
$User_name=$a;
$n_title = mysqli_real_escape_string($link, $_REQUEST['n_title']);
$n_des = mysqli_real_escape_string($link, $_REQUEST['n_des']);

$Status='1';
$sql = "INSERT into notice (User_name, n_title, n_des , uploaded_on,Status) VALUES ('$User_name', '$n_title',
	  '$n_des',  NOW(),'$Status')";
	 


if(mysqli_query($link, $sql)){
	 header("location:upload.php");
	 exit;

	
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// close connection
mysqli_close($link);
?>