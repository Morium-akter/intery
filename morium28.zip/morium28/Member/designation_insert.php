<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "", "morium");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
 $designation = mysqli_real_escape_string($link, $_REQUEST['designation']);
 $dpt = mysqli_real_escape_string($link, $_REQUEST['dpt']);

// Attempt update query execution
$sql = "INSERT into designation (designation,dpt) VALUES ('$designation','$dpt')";


if(mysqli_query($link, $sql)){
	header('Location: Member_apply_form.php');
exit;
} else {
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>