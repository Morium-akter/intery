
<?php

require_once "../config.php";

if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
$id = mysqli_real_escape_string($link, $_REQUEST['id']); 
$c = mysqli_real_escape_string($link, $_REQUEST['c']);
$course_code = mysqli_real_escape_string($link, $_REQUEST['courseID']);
$sql = "INSERT into offer_course (s_id,course_id,course_code) VALUES ('$id','$c','$course_code')";
   


if(mysqli_query($link, $sql)){
	
    include("Courseoffering_form.php");
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// close connection
mysqli_close($link);
?>