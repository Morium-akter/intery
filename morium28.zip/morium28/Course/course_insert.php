
<?php

require_once "../config.php";

if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
$id = mysqli_real_escape_string($link, $_REQUEST['id']);
$course_code = mysqli_real_escape_string($link, $_REQUEST['course_code']); 
$course_name = mysqli_real_escape_string($link, $_REQUEST['course_name']);
$credit = mysqli_real_escape_string($link, $_REQUEST['credit']);
$sql = "INSERT into course (course_code,course_name,credit) VALUES ('$course_code','$course_name','$credit')";
   


if(mysqli_query($link, $sql)){
	
    include("Courseoffering_form.php");
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// close connection
mysqli_close($link);
?>