<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; }
        .wrapper{ width: 350px; padding: 20px; }
		* {
			  margin: 0;
			}
			.top_head{
				overflow:hidden;
				height:70px;
				background:#128C41;
				text-align: center;
				padding:5px;
				
			}
			.top_child{
				overflow:hidden;
				height:60px;
				background:#333;
			}

			.top_child ul{
				margin-left:0px;
			}

			.top_child ul li{
			float:left;
			padding:17px;
			list-style-type: none;
			}

			.top_child ul li a{
			color:white;
			text-decoration:none;
			padding: 10px;
			}
			.top_child ul li a:hover{
				background:white;
				color:black;
				padding:10px 10px;
			}
			.middle_area
			{
			background-color:#B3CBD2;
			width:100%;
			overflow:hidden;
			height:500px;
			
			}
			.btn{
				margin-left: 80px;
			}
            .button{
				color:white;
				background-color: #4CAF50;
				border:none;
				border-radius:12px;
				padding: 15px;
				margin: 4px 2px;
			}			
			.row{
            width:100%;
            }


           .column {
           float: left;
           width: 25%;
           padding: 10px;
           height: 500px; 
           }
           .column1 {
		   margin-left:50px;
           float: left;
           width: 40%;
           padding: 10px;
           height: 500px;
           margin-left:50px;		   
           }
		   .column3 {
           float: left;
           width: 25%;
           padding: 10px;
           height: 500px; 
           }
    </style>
</head>
<body>
<div class="top_head">
		  <h1>IUBAT IT society management system</h1>
		</div>
		<div class="top_child">
			<ul>
				<li><a href="../after_admin_login_home.php">Home</a></li>
				<li><a href="">Notice</a></li>
				<li><a href="loantype.html">Mentoring Class</a></li>
				<li><a href="#">Member</a></li>
				<li><a href="#">Event</a></li>
				<li><a href="#">Finance</a></li>
				<li><a href="logout.php">Logout</a></li>
			</ul>
		</div>
<div class="middle_area">
<div class="row">
  <div class="column1" style="background-color:#B3CBD2;">
     <h3>Please select course for <?php
	 $con=mysqli_connect("localhost","root","","morium");
	 if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
       $id = mysqli_real_escape_string($con, $_REQUEST['id']);
	   $sql="SELECT semester FROM semester WHERE id='$id';"	;		  
$result = mysqli_query($con,$sql);
				 
while($row = mysqli_fetch_array($result)) 
	{ 
		$c=$row['semester']  ;
	}
	  echo $c; 
	 ?></h3>
<?php
$con=mysqli_connect("localhost","root","","morium");
// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
//print_r($_REQUEST);
$id = mysqli_real_escape_string($con, $_REQUEST['id']);
//$sql="SELECT course.course_code FROM course WHERE course_code not in ( SELECT course_code FROM offer_course JOIN semester on semester.id=offer_course.s_id);";
//echo $sql;
//exit;	
$m=$id;
//echo $m;
$sql="SELECT course_code,id FROM course WHERE id not in(SELECT offer_course.course_id from offer_course WHERE s_id='$id');"	;		  
$result = mysqli_query($con,$sql);
				 
while($row = mysqli_fetch_array($result)) 
	{ 
		$c=$row['id']  ;
            $a=$row['course_code'];  
            
			?>
			<form action="Course_offering_insert.php" method="post" >
			<input type="hidden" value="<?php echo $row['course_code']; ?>" name="courseID">
			<input type="hidden" value="<?php echo $m; ?>" name="id">
			<input type="hidden" value="<?php echo $c; ?>" name="c">
                <input type="submit" value="<?php echo $row['course_code']?>">
            </form>
           
			<?php
				  
	}
	
	?>		 		 
	<!--?course_code=< echo $row['course_code']?>?s_id=$s_id
	<button onclick="this.disabled='disabled';this.style.backgroundColor = 'red';"type="button" >csc102</button>-->
</div>
<div class="column3" style="background-color:#A9DFBF; text-align:center;"><h4>New Course Add into database </h4>
  
			<div class="column2" style="text-align:center;" >
			   <h2></h2></br>
			  
        <form action="course_insert.php?id=<?php echo $m; ?>" method="post">
		
        <label for="course_code">Course code:</label><br>
        <input type="text" name="course_code" id="course_code"><br>
		 <label for="course_name">Course Name:</label><br>
        <input type="text" name="course_name" id="course_name"><br>
		 <label for="credit">Credit:</label><br>
        <input type="text" name="credit" id="credit"><br>
    <input type="submit" value="Submit"><br><br>
</form>
<h4> Course Delete From database </h4>
<div class="column2" style="text-align:center;" >
			   <h2></h2></br>
			  
        <form action="course_delete.php?id=<?php echo $m; ?>" method="post">
		
        <label for="course_code">Course Code:</label><br>
        <input type="text" name="course_code" id="course_code"><br>
		
    
    <input type="submit" value="Submit"><br>
</form>
</div>
		</div>
		</div>
  <div class="column" style="background-color:#B3CBD2;"><h3>Offered  course for <?php
	 $con=mysqli_connect("localhost","root","","morium");
	 if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
       $id = mysqli_real_escape_string($con, $_REQUEST['id']);
	   
	   $sql="SELECT semester FROM semester WHERE id='$id';"	;		  
$result = mysqli_query($con,$sql);
				 
while($row = mysqli_fetch_array($result)) 
	{ 
		$c=$row['semester']  ;
	}
	  echo $c; 
	 ?></h3><br>
  <div>
 <?php
$con=mysqli_connect("localhost","root","","morium");
// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$id = mysqli_real_escape_string($con, $_REQUEST['id']);
$m=$id;
$sql="SELECT course_code FROM offer_course WHERE s_id='$id'";
$result = mysqli_query($con,$sql);
				 
while($row = mysqli_fetch_array($result)) 
	{ 
		//$c=$row['course_id']  ;
            $a=$row['course_code']; 
			echo $a;
			echo "   ";
			?>
			<form action="course_offer_delete.php" method="post" >
			<input type="hidden" value="<?php echo $row['course_code']; ?>" name="id1">
			<input type="hidden" value="<?php echo $m; ?>" name="id">
                <input type="submit" value="delete">
            </form>
			<!--<a href="course_offer_delete.php?id1=<?php e//cho $row['course_code']?>">Delete</a><br>-->
			<?php
	}
	?>

		</div>
</div>	


	 	
   
			
				   
</body>
</html>
