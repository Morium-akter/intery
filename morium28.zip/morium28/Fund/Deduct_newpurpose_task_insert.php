<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "", "morium");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
$e_id = mysqli_real_escape_string($link, $_REQUEST['id']);
echo $e_id;
$result = mysqli_query($link,"SELECT  * FROM date WHERE e_id='$e_id'  ");
				 
while($row = mysqli_fetch_array($result)) 
	{ 
            $a=$row['date'];
	}
 
 $task_title = mysqli_real_escape_string($link, $_REQUEST['task_title']);
  $amount = mysqli_real_escape_string($link, $_REQUEST['amount']);
 $m_name = mysqli_real_escape_string($link, $_REQUEST['username']);
 $date =$a;
// Attempt upm_name query execution
$sql = "INSERT into event_task (e_id,task_title,m_name,amount,date) VALUES ('$e_id','$task_title','$m_name','$amount','$date')";
mysqli_query($link, $sql);

$sql1 = "INSERT into deduct_amount (e_id, name,purpose,amount,date,status) VALUES ('$e_id', '$m_name','$task_title','$amount','$date','0')";
if(mysqli_query($link, $sql1)){
	header("Location:Deduct_newpurpose_task.php");
    exit;
} else {
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>