

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; }
        .wrapper{ width: 350px; padding: 20px; }
		* {
			  margin: 0;
			}
			.top_head{
				overflow:hidden;
				height:70px;
				background:#128C41;
				text-align: center;
				padding:5px;
				
			}
			.top_child{
				overflow:hidden;
				height:60px;
				background:#333;
			}

			.top_child ul{
				margin-left:0px;
			}

			.top_child ul li{
			float:left;
			padding:17px;
			list-style-type: none;
			}

			.top_child ul li a{
			color:white;
			text-decoration:none;
			padding: 10px;
			}
			.top_child ul li a:hover{
				background:white;
				color:black;
				padding:10px 10px;
			}
			.middle_area
			{
			background-color:#B3CBD2;
			width:100%;
			overflow:hidden;
			height:500px;
			
			}
			.btn{
				margin-left: 80px;
			}
            .button{
				color:white;
				background-color: #4CAF50;
				border:none;
				border-radius:12px;
				padding: 15px;
				margin: 4px 2px;
			}			
				.row{
            width:100%;
            }


           .column {
			   margin-left:50px;
           float: left;
           width: 50%;
           padding: 10px;
           height: 500px; 
           }
		    table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #B3CBD2;;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
           
    </style>
</head>
<body>
<div class="top_head">
		  <h1>IUBAT IT society management system</h1>
		</div>
		<div class="top_child">
			<ul>
				<li><a href="../after_admin_login_home.php">Home</a></li>
				<li><a href="">Notice</a></li>
				<li><a href="">Mentoring Class</a></li>
				<li><a href="#">Member</a></li>
				<li><a href="#">Event</a></li>
				<li><a href="../logout.php">Logout</a></li>
			</ul>
		</div>
		<div class="middle_area">
		
<div class="row">

  <div class="column" style="background-color:#B3CBD2; text-align:center;"><h3>Change Membership Details
 </h3><br>
  <div>
  <?php
  $link = mysqli_connect("localhost", "root", "", "morium");
    $id1 = mysqli_real_escape_string($link, $_REQUEST['id']);
   $id = mysqli_real_escape_string($link, $_REQUEST['id1']);
   $sql = "SELECT * FROM event_task  WHERE task_id='$id' ";   
    $rs_result = mysqli_query ($link,$sql); 
echo"<table>
  <tr>
   <th>Purpose</th>
    <th>Name</th> 
	  <th>Amount</th>
    <th>Date</th> 
  </tr>";
				 
while($row = mysqli_fetch_array($rs_result)) 
	{ 
        
echo "<tr>
         <td>".$row["task_title"]."</td>
         <td>".$row["m_name"]."</td>
		 <td>".$row["amount"]."</td>
		  <td>".$row["date"]."</td>
		</tr>";
			
	}
	echo "</table>";
  ?>
  <br> <form action="Deduct_task_edit_insert1.php">
   <input type="hidden" id="id" name="id" value="<?php echo $id; ?>"><br>
   <input type="hidden" id="id1" name="id1" value="<?php echo $id1; ?>"><br>
  <label for="event_title">Purpose:</label><br>
  <input type="text" id="event_title" name="event_title" value=""><br>
  <label for="amount">Amount:</label><br>
  <input type="text" id="amount" name="amount" value=""><br><br>
  <input type="submit" value="Submit">
</form>

</div>
</div>	
				   
</body>
</html>
