

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
	    <link rel="stylesheet" 
     href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"> 
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; }
        .wrapper{ width: 350px; padding: 20px; }
		* {
			  margin: 0;
			}
			.top_head{
				overflow:hidden;
				height:70px;
				background:#128C41;
				text-align: center;
				padding:5px;
				
			}
			.top_child{
				overflow:hidden;
				height:60px;
				background:#333;
			}

			.top_child ul{
				margin-left:0px;
			}

			.top_child ul li{
			float:left;
			padding:17px;
			list-style-type: none;
			}

			.top_child ul li a{
			color:white;
			text-decoration:none;
			padding: 10px;
			}
			.top_child ul li a:hover{
				background:white;
				color:black;
				padding:10px 10px;
			}
			.middle_area
			{
			background-color:#B3CBD2;
			width:100%;
			overflow:hidden;
			height:500px;
			
			}
			.column {
           float: left;
           width: 55%;
           padding: 10px;
           height: 500px; 
           }
           .column1 {
		   margin-left:40px;
           float: left;
           width: 40%;
           padding: 10px;
           height: 500px;
           margin-left:50px;		   
           }
		   
		   table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #B3CBD2;;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}			
				
    </style>
</head>
<body>
<div class="top_head">
		  <h1>IUBAT IT society management system</h1>
		</div>
		<div class="top_child">
			<ul>
				<li><a href="../after_admin_login_home.php">Home</a></li>
				<li><a href="">Notice</a></li>
				<li><a href="">Mentoring Class</a></li>
				<li><a href="#">Member</a></li>
				<li><a href="#">Event</a></li>
				<li><a href="../logout.php">Logout</a></li>
			</ul>
		</div>
		<div class="middle_area">
		
<div class="row">
  <div class="column1" style="background-color:#B3CBD2;"><h3>New Event Title </h3>
  
   <?php
    $link = mysqli_connect("localhost", "root", "", "morium");
	$result = mysqli_query($link,"SELECT  MAX(e_id) FROM event_title ");
				 
while($row = mysqli_fetch_array($result)) 
	{ 
         $id= $row['MAX(e_id)'];  
	}
  ?>
  <h5 style="text-align:center;"><form action="date_insert2.php" method="post">
  <input type="hidden" value="<?php echo $id; ?>" name="e_id">
   <label for="date">Date:</label><br>
  <input type="date" name="date" id="date"><br>
  <input type="submit" value="Submit">
  
</form></h5>

<form action="Deduct_newpurpose_task_insert.php" method="post">
  <input type="hidden" value="<?php echo $id; ?>" name="id">
  <label for="task_title">Purpose:</label><br>
  <input type="text" name="task_title" id="task_title"><br>
  <label for="amount">amount:</label><br>
  <input type="text" name="amount" id="amount"><br>
   <label for="m_name">Member name:</label><br>
  <select name="username" class="form-control">
  <option value="" ></option>
<?php
$con=mysqli_connect("localhost","root","","morium");
$sql = mysqli_query($con, "SELECT username FROM member WHERE status = '1' ");
$row = mysqli_num_rows($sql);
while ($row = mysqli_fetch_array($sql)){
echo "<option value='". $row['username'] ."'>" .$row['username'] ."</option>" ;
}
?>
</select>
  
  <input type="submit" value="Submit">
</form>
			 		 
    </div>
	
	
  <div class="column" style="background-color:#bbb;"><h3>Details</h3><br>
  <?php 
  $con=mysqli_connect("localhost","root","","morium");
// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
 $limit = 7;  // Number of entries to show in a page. 
    // Look for a GET variable page if not found default is 1.      
    if (isset($_GET["page"])) {  
      $pn  = $_GET["page"];  
    }  
    else {  
      $pn=1;  
    };   
  
    $start_from = ($pn-1) * $limit;  
$result = mysqli_query($con,"SELECT  MAX(e_id) FROM event_title ");
				 
while($row = mysqli_fetch_array($result)) 
	{ 
         $id= $row['MAX(e_id)'];  
	}	
  
    $sql = "SELECT * FROM event_task  WHERE e_id='$id' ORDER By task_id DESC LIMIT $start_from, $limit ";   
    $rs_result = mysqli_query ($con,$sql); 
echo"<table>
  <tr>
   <th>Purpose</th>
    <th>Name</th> 
	  <th>Amount</th>
    <th>Date</th> 
  </tr>";
				 
while($row = mysqli_fetch_array($rs_result)) 
	{ 
        $id1=$row['task_id'];
echo "<tr>
         <td>".$row["task_title"]."</td>
         <td>".$row["m_name"]."</td>
		 <td>".$row["amount"]."</td>
		  <td>".$row["date"]."</td>"
		 ?>
		 <td><a href="Deduct_task_edit_form.php?id1=<?php echo $id1; ?>">Edit</td>
		 <?php
		 echo "</tr>";
			
	}
	echo "</table>";
  ?>
 <ul class="pagination"> 
      <?php   
        $sql = "SELECT COUNT(*) FROM event_task WHERE e_id='$id'";   
        $rs_result = mysqli_query($con,$sql);   
        $row = mysqli_fetch_row($rs_result);   
        $total_records = $row[0];   
          
        // Number of pages required. 
        $total_pages = ceil($total_records / $limit);   
        $pagLink = "";                         
        for ($i=1; $i<=$total_pages; $i++) { 
          if ($i==$pn) { 
              $pagLink .= "<li class='active'><a href='Event_task_form.php?page="
                                                .$i." & id=".$id."'>".$i."</a></li>"; 
          }             
          else  { 
              $pagLink .= "<li><a href='Event_task_form.php?page=".$i."& id=".$id."'> 
                                                ".$i."</a></li>";   
          } 
        };   
        echo $pagLink;   
      ?> 
      </ul> 
</div>
</div>
</div>
  			   
</body>
</html>
