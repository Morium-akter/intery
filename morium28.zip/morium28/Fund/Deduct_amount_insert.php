<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "", "morium");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
$e_id = mysqli_real_escape_string($link, $_REQUEST['e_id']);
$id=$e_id;
$result = mysqli_query($link,"SELECT  * FROM date WHERE e_id='$e_id'  ");
				 
while($row = mysqli_fetch_array($result)) 
	{ 
            $a=$row['date'];
	}
 $name = mysqli_real_escape_string($link, $_REQUEST['m_name']);
 $purpose = mysqli_real_escape_string($link, $_REQUEST['task_title']);
 $amount = mysqli_real_escape_string($link, $_REQUEST['amount']);
 //$result = mysqli_real_escape_string($link, $_REQUEST['result']);
 $date =$a;
 
 $sql1 = "UPDATE event_task SET amount='$amount' WHERE 	e_id='$e_id' AND m_name='$name' AND task_title='$purpose'";
  mysqli_query($link, $sql1);
  
   $sql3 = "SELECT * FROM event_task WHERE e_id='$e_id'";
     $rs_result = mysqli_query ($link,$sql3); 
	 $total=0;
 while($row = mysqli_fetch_array($rs_result)) 
	{ 
       
		$c=$row['amount'];
		$total=$total+$c;
		$result=$total;
	}
	
// Attempt upamount query execution
$sql2 = "INSERT into deduct_amount (e_id, name,purpose,amount,totalamount,date,status) VALUES ('$e_id', '$name','$purpose','$amount','$result ','$date','0')";
mysqli_query($link, $sql2);


 $sql = "UPDATE deduct_amount SET totalamount='$result' WHERE  e_id='$e_id'";

if(mysqli_query($link, $sql)){
	header("Location: Deduct_event_form.php?id=$id");
    exit;
} else {
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>