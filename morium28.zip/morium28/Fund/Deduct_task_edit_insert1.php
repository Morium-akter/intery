<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "", "morium");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 $id = mysqli_real_escape_string($link, $_REQUEST['id']);
  $id1 = mysqli_real_escape_string($link, $_REQUEST['id1']);
 $event_title = mysqli_real_escape_string($link, $_REQUEST['event_title']);
 $amount = mysqli_real_escape_string($link, $_REQUEST['amount']);

// Attempt update query execution
$sql = "UPDATE event_task SET task_title='$event_title', amount='$amount' WHERE 	task_id='$id'";
mysqli_query($link, $sql);

  $sql2 = "SELECT * FROM event_task WHERE task_id='$id'";
     $rs_result = mysqli_query ($link,$sql2); 
	 $total=0;
 while($row = mysqli_fetch_array($rs_result)) 
	{ 
       
		$a=$row['e_id'];
        $n=$row['m_name'];
	}
	 $sql3 = "SELECT * FROM event_task WHERE e_id='$a'";
     $rs_result = mysqli_query ($link,$sql3); 
	 $total=0;
 while($row = mysqli_fetch_array($rs_result)) 
	{ 
       
		$c=$row['amount'];
		$total=$total+$c;
		$result=$total;
	}
$b=$result;
	$sql4 = "UPDATE deduct_amount SET totalamount='$b' WHERE  e_id='$a'";
	mysqli_query($link, $sql4);

$sql1 = "UPDATE deduct_amount SET purpose='$event_title', amount='$amount' WHERE 	name='$n' AND e_id='$a'";

if(mysqli_query($link, $sql1)){
  header("Location: Deduct_event_form.php?id=$id1");
exit;

} else {
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>