<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "", "morium");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 $name = mysqli_real_escape_string($link, $_REQUEST['name']);
 $purpose = mysqli_real_escape_string($link, $_REQUEST['purpose']);
 $amount = mysqli_real_escape_string($link, $_REQUEST['amount']);
 $date = mysqli_real_escape_string($link, $_REQUEST['date']);
// Attempt upamount query execution
$sql = "INSERT into add_amount (name,purpose,amount,date,status) VALUES ('$name','$purpose','$amount','$date','0')";


if(mysqli_query($link, $sql)){
	header("Location: ../after_admin_login_home.php");
    exit;
} else {
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>