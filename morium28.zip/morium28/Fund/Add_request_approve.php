<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$con = mysqli_connect("localhost", "root", "", "morium");
 
// Check connection
if($con === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 $id = mysqli_real_escape_string($con, $_REQUEST['id']);
 $sql = "UPDATE add_amount SET status='1' WHERE  a_id='$id'";
 mysqli_query($con, $sql);
 
  $sql1 = "SELECT * FROM add_amount  WHERE a_id='$id'";   
    $rs_result1 = mysqli_query ($con,$sql1); 
			 
while($row = mysqli_fetch_array($rs_result1)) 
	{ 
		 $amount= $row['amount'];
	}

	$result = mysqli_query($con,"SELECT  MAX(t_id) FROM transection ");
				 
while($row = mysqli_fetch_array($result)) 
	{ 
         $a= $row['MAX(t_id)'];  
	}
	
	 $sql3 = "SELECT * FROM transection  WHERE t_id='$a'";   
    $rs_result3 = mysqli_query ($con,$sql3); 			 
while($row = mysqli_fetch_array($rs_result3)) 
	{ 
		 $Total_amount= $row['Total_amount'];
	}
	
	$new=$Total_amount+$amount;
	
// Attempt update query execution
 $sql4 = "INSERT into transection (a_id,type,amount,Total_amount) VALUES ('$id','add','$amount','$new')";



if(mysqli_query($con, $sql4)){
	header("location: ../Co-ordinator_home.php");
	 exit;
    
} else {
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($con);
}
 
// Close connection
mysqli_close($con);
?>