

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
	    <link rel="stylesheet" 
     href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"> 
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; }
        .wrapper{ width: 350px; padding: 20px; }
		* {
			  margin: 0;
			}
			.top_head{
				overflow:hidden;
				height:70px;
				background:#128C41;
				text-align: center;
				padding:5px;
				
			}
			.top_child{
				overflow:hidden;
				height:60px;
				background:#333;
			}

			.top_child ul{
				margin-left:0px;
			}

			.top_child ul li{
			float:left;
			padding:17px;
			list-style-type: none;
			}

			.top_child ul li a{
			color:white;
			text-decoration:none;
			padding: 10px;
			}
			.top_child ul li a:hover{
				background:white;
				color:black;
				padding:10px 10px;
			}
			.middle_area
			{
			background-color:#B3CBD2;
			width:100%;
			overflow:hidden;
			height:500px;
			
			}
			.column {
           float: left;
           width: 15%;
           padding: 10px;
           height: 500px; 
           }
           .column1 {
		   margin-left:40px;
           float: left;
           width: 75%;
           padding: 10px;
           height: 500px;
           margin-left:50px;		   
           }
		   
		   table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #B3CBD2;;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}			
				
    </style>
</head>
<body>
<div class="top_head">
		  <h1>IUBAT IT society management system</h1>
		</div>
		<div class="top_child">
			<ul>
				<li><a href="../Co-ordinator_home.php">Home</a></li>
				<li><a href="">Notice</a></li>
				<li><a href="">Mentoring Class</a></li>
				<li><a href="#">Member</a></li>
				<li><a href="#">Event</a></li>
				<li><a href="../logout.php">Logout</a></li>
			</ul>
		</div>
		<div class="middle_area">
		
<div class="row">
  <div class="column1" style="background-color:#B3CBD2; text-align:center;"><h3>Request for Add amount</h3><br>
     <?php 
  $con=mysqli_connect("localhost","root","","morium");
// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
    $id = mysqli_real_escape_string($con, $_REQUEST['e_id']);
  
    $sql = "SELECT * FROM deduct_amount  WHERE e_id='$id'  ";   
    $rs_result = mysqli_query ($con,$sql); 
echo"<table>
  <tr>
   <th>Name</th>
    <th>purpose</th> 
	 <th>amount</th>
	  <th>Date</th>
  </tr>";
				 
while($row = mysqli_fetch_array($rs_result)) 
	{ 
        $did=$row['d_id'];
		$total=$row['totalamount'];
echo "<tr>
         <td>".$row["name"]."</td>
         <td>".$row["purpose"]."</td>
		 <td>".$row["amount"]."</td>
		 <td>".$row["date"]."</td>
		 </tr>";
			
	}
	echo "</table>";
	
  ?>
  <h4>Total amount = <?php echo $total;?></h4><br>
            <form action="Deduct_request_approve.php" method="post" >
			<input type="hidden" value="<?php echo $total; ?>" name="amount">
			<input type="hidden" value="<?php echo $id; ?>" name="id">
			<input type="submit" value="Approve">
            </form><br>
			<form action="Deduct_request_reject.php" method="post" >
			<input type="hidden" value="<?php echo $id; ?>" name="id">
			<input type="submit" value="Reject">
            </form>
    </div>
	
	
</div>
</div>
  			   
</body>
</html>