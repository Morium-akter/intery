<!DOCTYPE html>
<!-- saved from url=(0048)file:///C:/Users/Student/Desktop/Test/index.html -->
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
		<title>
		</title>
		<style>
			* {
			  margin: 0;
			}
			.top_head{
				overflow:hidden;
				height:40px;
				background:#128C41;
				text-align: center;
				padding:17px;
				
			}
			.top_child{
				overflow:hidden;
				height:60px;
				background:#333;
			}

			.top_child ul{
				margin-left:0px;
			}

			.top_child ul li{
			float:left;
			padding:17px;
			list-style-type: none;
			}

			.top_child ul li a{
			color:white;
			text-decoration:none;
			padding: 10px;
			}
			.top_child ul li a:hover{
				background:white;
				color:black;
				padding:10px 10px;}

			.middle_area
			{
			width:100%;
			overflow:hidden;
			height:500px;
			}

			footer {
			text-align:center;
			background:#777;
			heigth:60px;
		  padding: 10px;
			}
			img {
				width: 100%;
				height: auto;
			}
		</style>
	</head>
	<body>

		<!-- Top Area -->
		<div class="top_head">
		  <h1>IUBAT IT society management system</h1>
		</div>
		<div class="top_child">
			<ul>
				<li><a href="AdminLogin.php">Admin login</a></li>
				<li><a href="userlogin.php">User Login</a></li>
				<li><a href="loantype.html">Co-ordinator Login</a></li>
				<li><a href="#">Faculty Login</a></li>
				
			</ul>
		</div>

		<div class="middle_area">
			<img src="iubat.jpg">
			</div>
		<footer>
			<h5>IUBAT</h5>
		</footer>
</body>
</html>
