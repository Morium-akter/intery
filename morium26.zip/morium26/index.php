<!DOCTYPE html>
<!-- saved from url=(0048)file:///C:/Users/Student/Desktop/Test/index.html -->
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
		<title>
		IITS
		</title>
		    <!--<link rel="stylesheet" href="stylecss.css">-->
		<style>
		* {
			  margin: 0;
			}
			.top_head{
				overflow:hidden;
				height:70px;
				background:#4C9717;
				text-align: center;
				width:100%;
				
			}
			.top_head_left{
				float: left;
                width: %;
                padding: 5px;
                height: 70px;
				background:white;
			}
			.top_head_middle{
				float: left;
                width: 7%;
				color:white;
                padding: 16px;
                height: 70px; 
			}
			.top_head_right{
				float: left;
                width: 70%;
                padding: 10px;
                height: 70px; 
			}
			.top_child{
				overflow:hidden;
				height:60px;
				background:#4C9717;
			}

			.top_child ul{
				margin-right:0px;
			}

			.top_child ul li{
			float:right;
			padding:17px;
			list-style-type: none;
			}

			.top_child ul li a{
			color:white;
			text-decoration:none;
			padding: 10px;
			font-size: 20px;
			font-weight: bold;
			}
			.top_child ul li a:hover{
			background:white;
			color:#4C9717;
				}

			
			.middle_area {
            position: relative;
            width:100%;
			overflow:hidden;
			height:620px;
            margin: 0 auto;
            }

           .middle_area img {
			   vertical-align: middle;
			   }

            .middle_area .content {
             position: absolute;
			 text-align:left;
             bottom: 0;
             width: 80%;
			 padding:250px;
			 color:red;
			 font-size:30px;
			 background: rgb(0, 0, 0); /* Fallback color */
             background: rgba(0, 0, 0, 0.5);
            }
			#university {
				width: 100%;
				height: auto;
			}
			#iubatlogo {
				width: 100px;
				height: 60px;
			}
			.login_top_child{
				color:white;
			}
			
			
			
			
		</style>
	</head>
	<body>

		<!-- Top Area -->
	<div class="top_head">
		<div class="top_head_left" > 
		    <img id="iubatlogo"src="iubatlogo.jpg">
		</div>
        <div class="top_head_middle"  >		
		    <h1>IUBAT</h1>
		</div>
		<div class="top_head_right" >
		    <div class="top_child">
			<ul>
				<li><a href="AdminLogin.php">Admin login</a></li>
				<li><a href="userlogin.php">User Login</a></li>
				<li><a href="co-ordinator_login.php">Co-ordinatorlogin</a></li>
				<li><a href="Faculty.php">Faculty Login</a></li>
			</ul>
		    </div>
		</div>
	</div>
		
		<div class="middle_area">
			<img id="university"src="university.jpg">
			<div class="content">
    <h1>Welcome To <br>IUBAT IT Society</h1>
    
  </div>
		</div>

</body>
</html>
