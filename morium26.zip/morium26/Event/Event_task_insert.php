<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "", "morium");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 $e_id = mysqli_real_escape_string($link, $_REQUEST['id']);
 $id=$e_id;
 $task_title = mysqli_real_escape_string($link, $_REQUEST['task_title']);
 $m_name = mysqli_real_escape_string($link, $_REQUEST['username']);

// Attempt upm_name query execution
$sql = "INSERT into event_task (e_id,task_title,m_name) VALUES ('$e_id','$task_title','$m_name')";


if(mysqli_query($link, $sql)){
	header("Location: Event_task_form.php?id=$id");
    exit;
} else {
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>