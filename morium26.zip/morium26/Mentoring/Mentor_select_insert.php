<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "", "morium");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
 $id1 = mysqli_real_escape_string($link, $_REQUEST['id']);
 $room= mysqli_real_escape_string($link, $_REQUEST['room']);
 $starttime= mysqli_real_escape_string($link, $_REQUEST['starttime']);
 $endtime= mysqli_real_escape_string($link, $_REQUEST['endtime']);
 $day = mysqli_real_escape_string($link, $_REQUEST['day']);
 $status='1';

// Attempt update query execution
$sql = "UPDATE mentor_apply SET status='$status',room='$room',starttime='$starttime',endtime='$endtime',day='$day' WHERE id='$id1'";


if(mysqli_query($link, $sql)){
	 header('Location: Mentoring_apply_form.php');
exit;
    
} else {
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>