

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; }
        .wrapper{ width: 350px; padding: 20px; }
		* {
			  margin: 0;
			}
			.top_head{
				overflow:hidden;
				height:70px;
				background:#128C41;
				text-align: center;
				padding:5px;
				
			}
			.top_child{
				overflow:hidden;
				height:60px;
				background:#333;
			}

			.top_child ul{
				margin-left:0px;
			}

			.top_child ul li{
			float:left;
			padding:17px;
			list-style-type: none;
			}

			.top_child ul li a{
			color:white;
			text-decoration:none;
			padding: 10px;
			}
			.top_child ul li a:hover{
				background:white;
				color:black;
				padding:10px 10px;
			}
			.middle_area
			{
			background-color:#B3CBD2;
			width:100%;
			overflow:hidden;
			height:500px;
			
			}
			.btn{
				margin-left: 80px;
			}
            .button{
				color:white;
				background-color: #4CAF50;
				border:none;
				border-radius:12px;
				padding: 15px;
				margin: 4px 2px;
			}			
				.row{
            width:100%;
            }


           .column {
           float: left;
           width: 40%;
           padding: 10px;
           height: 500px; 
           }
           .column1 {
		   margin-left:50px;
           float: left;
           width: 50%;
           padding: 10px;
           height: 500px;
           margin-left:50px;		   
           }
		   table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #B3CBD2;;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
    </style>
</head>
<body>
<div class="top_head">
		  <h1>IUBAT IT society management system</h1>
		</div>
		<div class="top_child">
			<ul>
				<li><a href="../after_admin_login_home.php">Home</a></li>
				<li><a href="">Notice</a></li>
				<li><a href="">Mentoring Class</a></li>
				<li><a href="#">Member</a></li>
				<li><a href="#">Event</a></li>
				<li><a href="../logout.php">Logout</a></li>
			</ul>
		</div>
		<div class="middle_area">
		
<div class="row">

  <div class="column" style="background-color:#B3CBD2; text-align:center;"><h3>Mentoring Class Routine
  <?php 
  $con=mysqli_connect("localhost","root","","morium");
  $semester = mysqli_real_escape_string($con, $_REQUEST['semester']); 
  echo $semester;
  ?></h3><br>
  <div>
 <?php
$con=mysqli_connect("localhost","root","","morium");
// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$semester = mysqli_real_escape_string($con, $_REQUEST['semester']);
$qr="SELECT id FROM semester WHERE semester='$semester' ";
$r = mysqli_query($con,$qr);

while ($row = $r->fetch_assoc())
{
	 $s=$row['id'];
}

$result = mysqli_query($con,"SELECT id,ID_no,username,email,phone_number,Course_Code,room,time,day FROM mentor_apply WHERE (s_id='$s' AND status='1') ");
echo"<table>
  <tr>
    <th>ID</th>
    <th>User Name</th>
    <th>Email</th>
    <th>Phone Number</th>
    <th>Course Code</th>
     <th>Room No</th>
    <th>Time</th>
    <th>day</th>	
  </tr>";
				 
while($row = mysqli_fetch_array($result)) 
	{ 
        $idno=$row['id'];
		echo "<tr>
		
         <td>".$row["ID_no"]."</td>
         <td>".$row["username"]."</td>
		 <td>".$row["email"]."</td>
         <td>".$row["phone_number"]."</td>
		 <td>".$row["Course_Code"]."</td>
		 <td>".$row["room"]."</td>
         <td>".$row["time"]."</td>
		 <td>".$row["day"]."</td>"
		 
            
			?>
			<td><a href="Mentor_select_form.php?id=<?php echo $row['id']?>">Change</a></td>
			
           
			<?php		  
	}
	echo "</tr>";
	echo "</table>";
	?>		

		</div>
</div>	
				   
</body>
</html>
