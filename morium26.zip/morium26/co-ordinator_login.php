<?php
// Initialize the session
session_start();

// Check if the user is already logged in, if yes then redirect him to welcome page
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
  header("location: home.php");
  exit;
}

// Include config file
require_once "config.php";

// Define variables and initialize with empty values
$email = $password = "";
$email_err = $password_err = "";

// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){

    // Check if email is empty
    if(empty(trim($_POST["email"]))){
        $email_err = "Please enter email.";
    } else{
        $email = trim($_POST["email"]);
    }

    // Check if password is empty
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter your password.";
    } else{
        $password = trim($_POST["password"]);
    }

    // Validate credentials
    if(empty($email_err) && empty($password_err)){
        // Prepare a select statement
        $sql = "SELECT id, email, password FROM coordinator WHERE email = ?";

        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_email);

            // Set parameters
            $param_email = $email;

            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Store result
                mysqli_stmt_store_result($stmt);

                // Check if email exists, if yes then verify password
                if(mysqli_stmt_num_rows($stmt) == 1){
                    // Bind result variables
                    mysqli_stmt_bind_result($stmt, $id, $email, $hashed_password);
                    if(mysqli_stmt_fetch($stmt)){
                        if(password_verify($password, $hashed_password)){
                            // Password is correct, so start a new session
                            session_start();

                            // Store data in session variables
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id"] = $id;
                            $_SESSION["email"] = $email;

                            // Redirect user to welcome page
                            header("location: Co-ordinator_home.php");
                        } else{
                            // Display an error message if password is not valid
                            $password_err = "The password you entered was not valid.";
                        }
                    }
                } else{
                    // Display an error message if email doesn't exist
                    $email_err = "No account found with that email.";
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
        }

        // Close statement
        mysqli_stmt_close($stmt);
    }

    // Close connection
    mysqli_close($link);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    
    <style type="text/css">
        * {
			  margin: 0;
			}
			.top_head{
				overflow:hidden;
				height:70px;
				background:#4C9717;
				
			}
			.top_head_left{
				float: left;
                width: %;
                padding: 5px;
                height: 70px;
				background:white;
			}
			#iubatlogo {
				width: 100px;
				height: 60px;
			}
			.top_head_middle{
				float: left;
                width: 7%;
				color:white;
                padding: 16px;
                height: 70px; 
			}
			.top_head_right{
				float: left;
                width: 70%;
                padding: 16px;
                height: 70px;
                text-align:center;
	 }
       
		.login_top_child{
				color:white;
			}
		.middle_area{
			  text-align:center;
			  background:#CCE8FF;
			  height:550px;
			  width:100%;
		}
    </style>
</head>
<body>
 <div class="top_head">
		<div class="top_head_left" > 
		    <img id="iubatlogo"src="iubatlogo.jpg">
		</div>
        <div class="top_head_middle"  >		
		    <h1>IUBAT</h1>
		</div>
		<div class="top_head_right" >
		    <div class="login_top_child">
               <h1>IUBAT IT Society</h1>
		    </div>
		</div>
	</div>
<div class="middle_area">
		
		 <div class="row">
		   
			    <div class="col-md-4">
			     </div>
			   <div class="col-md-4"></br></br>
			   
			   <h2>Please Fillup your information to login</h2></br></br>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group <?php echo (!empty($email_err)) ? 'has-error' : ''; ?>">
                <br><label>Email</label><br>
                <input type="text" name="email" class="form-control" value="<?php echo $email; ?>">
                <span class="help-block"><?php echo $email_err; ?></span>
            </div>
            <div class="form-group <?php echo (!empty($password_err)) ? 'has-error' : ''; ?>">
                <br><label>Password</label><br>
                <input type="password" name="password" class="form-control">
                <span class="help-block"><?php echo $password_err; ?></span>
            </div>
            <div class="form-group">
               <br> <input type="submit" class="btn btn-primary" value="Login">
            </div>
            <!--<p>Don't have an account? <a href="registrar.php">Sign up now</a>.</p>-->
        </form>
    </div>
	 <div class="col-md-4">
	</div>
			
				   
</body>
</html>
