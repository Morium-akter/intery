<?php session_start();
//var_dump($_SESSION);
$ID=$_SESSION['id'];
$con=mysqli_connect("localhost","root","","morium");
$result = mysqli_query($con,"SELECT ID_no, username,email,phone_number FROM s_user  WHERE id='$ID' ");
while ($row = $result->fetch_assoc()) {
	$d=$row['ID_no'];
    $a= $row['username'];
	$b= $row['email'];
	$c=$row['phone_number'];
}
?>

<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
require_once "../config.php";

if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

$qr="SELECT s_id FROM mentor_sem ";
$r = mysqli_query($con,$qr);

while ($row = $r->fetch_assoc())
{
	 $s=$row['s_id'];
}
$s_id=$s;
$ID_no=$d;
$User_name=$a;
$email=$b;
$phone_number=$c;
$cgpa = mysqli_real_escape_string($link, $_REQUEST['cgpa']);
$designation = mysqli_real_escape_string($link, $_REQUEST['designation']);
$dpt = mysqli_real_escape_string($link, $_REQUEST['dpt']);
$status='0';


   $sql = "INSERT into member (ID_no,username, email, phone_number, cgpa, designation, dpt, status) VALUES ( '$ID_no','$User_name', '$email', '$phone_number', '$cgpa','$designation','$dpt','$status')";
            
    //$statusMsg = 'Please select a file to upload.';


// Display status message

 
// Check connection


if(mysqli_query($link, $sql)){
	
     header('Location: user_apply_success_form.php');
      exit;
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// close connection
mysqli_close($link);
?>