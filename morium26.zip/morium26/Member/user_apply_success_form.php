

<!DOCTYPE html>
<!-- saved from url=(0048)file:///C:/Users/Student/Desktop/Test/index.html -->
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
		<title>
		</title>
		<style>
			* {
			  margin: 0;
			}
			.top_head{
				overflow:hidden;
				height:40px;
				background:#128C41;
				text-align: center;
				padding:17px;
				
			}
			.top_child{
				overflow:hidden;
				height:60px;
				background:#333;
			}

			.top_child ul{
				margin-left:0px;
			}

			.top_child ul li{
			float:left;
			padding:17px;
			list-style-type: none;
			}

			.top_child ul li a{
			color:white;
			text-decoration:none;
			padding: 10px;
			}
			
			.top_child ul li a:hover{
				background:white;
				color:black;
				padding:10px 10px;}
		    .dropdown {
  float: left;
  overflow: hidden;
}

.dropdown .dropbtn {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.navbar a:hover, .dropdown:hover .dropbtn {
  background-color: white;
  color:black;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 120px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  float: none;
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
  background-color: #ddd;
}

.dropdown:hover .dropdown-content {
  display: block;
}

			.middle_area
			{
			width:100%;
			overflow:hidden;
			height:500px;
			background-color:#B3CBD2;
			}

			footer {
			text-align:center;
			background:#777;
			heigth:60px;
		  padding: 10px;
			}
			img {
				width: 100%;
				height: auto;
			}
		</style>
	</head>
	<body>

		<!-- Top Area -->
		<div class="top_head">
		  <h1>IUBAT IT society management system</h1>
		</div>
		<div class="top_child">
			<ul>
				<li><a href="../after_user_login_home.php">Home</a></li>
				<div class="dropdown">
    <button class="dropbtn">Notice 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="Notice_form_user.php">Upload Notice</a>
      <a href="Notice_view_user.php">View Notice</a>
     
    </div>
  </div> 
				<div class="dropdown">
    <button class="dropbtn">MentoringClass 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="Notice_view.php">View Routine</a>
     <a href="Mentoring/user_apply_form.php">Apply</a>
    </div>
  </div> 
				<li><a href="#">Member</a></li>
				<li><a href="#">Event</a></li>
				<li><a href="logout.php">Logout</a></li>
			</ul>
		</div>

		<div class="middle_area">
			<h3 style="text-align:center;">Your Application is succsessfully done.</h3>
			</div>
		<footer>
			<h5>IUBAT</h5>
		</footer>
</body>
</html>
