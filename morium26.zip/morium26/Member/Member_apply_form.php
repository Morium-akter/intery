<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; }
        .wrapper{ width: 350px; padding: 20px; }
		* {
			  margin: 0;
			}
			.top_head{
				overflow:hidden;
				height:70px;
				background:#128C41;
				text-align: center;
				padding:5px;
				
			}
			.top_child{
				overflow:hidden;
				height:60px;
				background:#333;
			}

			.top_child ul{
				margin-left:0px;
			}

			.top_child ul li{
			float:left;
			padding:17px;
			list-style-type: none;
			}

			.top_child ul li a{
			color:white;
			text-decoration:none;
			padding: 10px;
			}
			.top_child ul li a:hover{
				background:white;
				color:black;
				padding:10px 10px;
			}
			.middle_area
			{
			width:100%;
			overflow:hidden;
			height:500px;
			background-color:#B3CBD2;
			}
			.row{
            width:100%;
			background-color:#B3CBD2;
            }


           .column {
           float: left;
           width: 25%;
           padding: 10px;
           height: 500px; 
           }
           .column1 {
		  
           float: left;
           width: 20%;
           padding: 10px;
           height: 500px;
           margin-left:25px;	   
           }
		   .column2 {
		   
           float: left;
           width: 30%;
           padding: 10px;
           height: 500px;
           		   
           }
		   .column3 {
		   
           float: left;
           width: 20%;
           padding: 10px;
           height: 500px;
           		   
           }
		    table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 80%;
}

td, th {
  border: 1px solid #B3CBD2;;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
				
    </style>
</head>
<body>
<div class="top_head">
		  <h1>IUBAT IT society management system</h1>
		</div>
		<div class="top_child">
			<ul>
				<li><a href="../after_admin_login_home.php">Home</a></li>
				<li><a href="">Notice</a></li>
				<li><a href="loantype.html">Mentoring Class</a></li>
				<li><a href="#">Member</a></li>
				<li><a href="#">Event</a></li>
				<li><a href="#">Finance</a></li>
				<li><a href="../logout.php">Logout</a></li>
			</ul>
		</div>

<div class="row">
  <div class="column1" style="background-color:#bbb;">
			   <h2><?php
$con=mysqli_connect("localhost","root","","morium");
// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
				 
$result = mysqli_query($con,"SELECT status FROM configur  WHERE id='2'");
          
	while ($row = $result->fetch_assoc()) {
    $a= $row['status'];
	
}
	if($a=='1'){
		echo "Now Apply section is blocked";?>
		<form action="Apply_Section_insert.php" method="post" >
			<input type="hidden" value="0" name="id">
			<input type="submit" value="Start">
            </form>
			<?php
	}
	else{
		echo "Now Apply section is opened";
		?>
		<form action="Apply_Section_insert.php" method="post" >
			<input type="hidden" value="1" name="id">
			<input type="submit" value="Stop">
            </form>
			<?php
	}

mysqli_close($con);
?> </h2>

    </div>
	<div class="column" style="background-color:#B3CBD2;"><h3> Insert Designation Name</h3><br>
  <div>
    <form action="designation_insert.php" method="post">
        <label for="designation">Designation Name:</label><br>
        <input type="text" name="designation" id="designation"><br>
		<label for="dpt">Department:</label><br>
        <input type="text" name="dpt" id="dpt"><br>
    <input type="submit" value="Submit"><br><br>
</form>

</div>
</div>
<div class="column2" style="background-color:#bbb;"><h3>Designation Details</h3><br>
	<div>
 <?php
$con=mysqli_connect("localhost","root","","morium");
// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
$sql="SELECT * FROM designation WHERE status='0' ";
$result = mysqli_query($con,$sql);
echo"<table>
  <tr>
    <th>Designation</th>
    <th>Department</th>
    <th></th>	
	<th>Select for apply</th>	
  </tr>";
				 
while($row = mysqli_fetch_array($result)) 
	{ 
        $a=$row['id'];
           echo "<tr>
              <td>".$row["designation"]."</td>
		 <td>".$row["dpt"]."</td>"
		
		 ?>
		 <td><a href="designation_delete.php?id=<?php echo $a?> ">del</a></td>
		 <td><a href="Member_apply_insert.php?id=<?php echo $a?>">apply</a></td>
		 <?php
		 echo" </tr>";
			
	}
		
	echo "</table>";
	?>

		</div> 
			
		</div>
		<div class="column3" style="background-color:#B3CBD2;">
		<h3 style = "text-align:center;"><form action="See_request_application.php" method="">
    <input type="submit" value="See application">
</form>
 </h3>
		<h3> Designation for application </h3><br>
  <div>
  <?php
$con=mysqli_connect("localhost","root","","morium");
// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
$sql="SELECT * FROM designation WHERE status ='1' ";
$result = mysqli_query($con,$sql);
echo"<table>
  <tr>
    <th>Designation</th>
    <th>Department</th>
    	
  </tr>";
				 
while($row = mysqli_fetch_array($result)) 
	{ 
        $b=$row['id'];
           echo "<tr>
              <td>".$row["designation"]."</td>
		 <td>".$row["dpt"]."</td>"
		
		 ?>
		 <td><a href="Mem_Apply_del.php?id=<?php echo $b?> ">del</a></td>
		 <?php
		 echo" </tr>";
			
	}
		
	echo "</table>";
	?>
  	</div>
</div>
</div>		
</body>
</html>
