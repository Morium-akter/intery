
<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "morium";
 $conn = new mysqli($host, $user, $password, $database);
        if($conn->connect_error){
            die("FAILED:" . $conn->connect_error);
        }  
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; }
        .wrapper{ width: 350px; padding: 20px; }
		* {
			  margin: 0;
			}
			.top_head{
				overflow:hidden;
				height:70px;
				background:#128C41;
				text-align: center;
				padding:5px;
				
			}
			.top_child{
				overflow:hidden;
				height:60px;
				background:#333;
			}

			.top_child ul{
				margin-left:0px;
			}

			.top_child ul li{
			float:left;
			padding:17px;
			list-style-type: none;
			}

			.top_child ul li a{
			color:white;
			text-decoration:none;
			padding: 10px;
			}
			.top_child ul li a:hover{
				background:white;
				color:black;
				padding:10px 10px;
			.middle_area
			{
			width:100%;
			overflow:hidden;
			height:500px;
			}	
				
    </style>
</head>

<body>
<div class="top_head">
		  <h1>IUBAT IT society management system</h1>
		</div>
		<div class="top_child">
			<ul>
				<li><a href="../after_admin_login_home.php">Home</a></li>
				<li><a href="">Notice</a></li>
				<li><a href="loantype.html">Mentoring Class</a></li>
				<li><a href="#">Member</a></li>
				<li><a href="#">Event</a></li>
				<li><a href="#">Finance</a></li>
				<li><a href="logout.php">Logout</a></li>
			</ul>
		</div>
<div class="middle_area">
		
		 <div class="row">
		   
			    <div class="col-md-4">
			     </div>
			   <div class="col-md-4"></br></br>
			   <h2>Upload Image/File</h2></br></br>
 <form method="POST" action="upload.php" enctype="multipart/form-data">
        <input type='file' name='file[]' multiple ><br>
  <input type='submit' value='submit' name='but_upload'>
    </form>
	 </div>
	 <div class="col-md-4">
	</div>
	<?php 
	$result = mysqli_query($conn,"SELECT  MAX(id) FROM notice ");
				 
while($row = mysqli_fetch_array($result)) 
	{ 
         $a= $row['MAX(id)'];  
	}
 
if(isset($_POST['but_upload'])){
	 $total = count($_FILES['file']['name']);
	
  for($i=0; $i<$total; $i++){
  $name = $_FILES['file']['name'][$i];
  $target_dir = "upload/";
  //$target_file = $target_dir . basename($_FILES["file"]["name"]);

  
  
     // Insert record
     $query = "insert into file (name,N_id) values('".$name."','$a')";
     mysqli_query($conn,$query);
  
     // Upload file
     move_uploaded_file($_FILES['file']['tmp_name'][$i],$target_dir.$name);
  }
 
  
 if($i==$total){
	
   header("location: Notice_upload_sucess.php");
	 exit;
}
}
 ?>
 
            
</body>
</html>