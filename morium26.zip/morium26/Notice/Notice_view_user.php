<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; }
        .wrapper{ width: 350px; padding: 20px; }
		* {
			  margin: 0;
			}
			.top_head{
				overflow:hidden;
				height:70px;
				background:#128C41;
				text-align: center;
				padding:5px;
				
			}
			.top_child{
				overflow:hidden;
				height:60px;
				background:#333;
			}

			.top_child ul{
				margin-left:0px;
			}

			.top_child ul li{
			float:left;
			padding:17px;
			list-style-type: none;
			}

			.top_child ul li a{
			color:white;
			text-decoration:none;
			padding: 10px;
			}
			.top_child ul li a:hover{
				background:white;
				color:black;
				padding:10px 10px;
			}
			.middle_area
			{
				
			background-color:#B3CBD2;
			width:100%;
			overflow:hidden;
			height:500px;
			}	
			            
        table {
			margin-left:30px;
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 95%;
}

td, th {
  border: 1px solid #B3CBD2;
  text-align: center;
  padding: 10px;
}

tr:nth-child(even) {
  background-color:skyblue;
}
tr:nth-child(odd) {
  background-color: #A6A6A6;
}
  .pagination{
	  margin-left:20px;
  }
    </style>
</head>
<body>
<div class="top_head">
		  <h1>IUBAT IT society management system</h1>
		</div>
		<div class="top_child">
			<ul>
				<li><a href="../after_user_login_home.php">Home</a></li>
				<li><a href="">Notice</a></li>
				<li><a href="loantype.html">Mentoring Class</a></li>
				<li><a href="#">Member</a></li>
				<li><a href="#">Event</a></li>
				
				<li><a href="../logout.php">Logout</a></li>
			</ul>
		</div>
<div class="middle_area">
		
		
			   
			   <h2 style="text-align:center;">Notice </h2>
<?php
$con=mysqli_connect("localhost","root","","morium");
// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
//$result = mysqli_query($con,"SELECT  id,User_name, n_title, uploaded_on FROM notice ORDER BY id DESC");
$limit = 5;  // Number of entries to show in a page. 
    // Look for a GET variable page if not found default is 1.      
    if (isset($_GET["page"])) {  
      $pn  = $_GET["page"];  
    }  
    else {  
      $pn=1;  
    };   
  
    $start_from = ($pn-1) * $limit;   
  
echo"<table>
  <tr>
    <th>User name</th>
    <th>Notice Title</th>
	 <th>Description</th>
    <th>Date-time</th>  	
  </tr>";
				 
$result = mysqli_query($con,"SELECT  * FROM notice  WHERE Status='1' ORDER BY id DESC LIMIT $start_from, $limit ");
				 
while($row = mysqli_fetch_array($result)) 
	{ 
         $a= $row['id'];
		 $b= $row['n_des'];
		  //echo "<img src='$image' >";
        		 
		echo "<tr > 
            <td>" . $row['User_name'] . "</td> 
            <td>" . $row['n_title'] . "</td>"?>
			<td><?php echo substr($b, 0, 10)?>.... <a href="Notice_descrip_code.php?id=<?php echo $row['id']?>">Read More</a><?php;?></td>
			
            <td> <?php echo $row['uploaded_on']?> </td>
			
			<?php
			echo "</tr>";
            
	}
  
        echo "</table>";

mysqli_close($con);
?> 

  <ul class="pagination"> 
      <?php   
	  $con=mysqli_connect("localhost","root","","morium");
        $sql = "SELECT COUNT(*) FROM notice WHERE Status='1'";   
        $rs_result = mysqli_query($con,$sql);   
        $row = mysqli_fetch_row($rs_result);   
        $total_records = $row[0];   
          
        // Number of pages required. 
        $total_pages = ceil($total_records / $limit);   
        $pagLink = "";                         
        for ($i=1; $i<=$total_pages; $i++) { 
          if ($i==$pn) { 
              $pagLink .= "<li class='active'><a href='Notice_view_user.php?page="
                                                .$i." '>".$i."</a></li>"; 
          }             
          else  { 
              $pagLink .= "<li><a href='Notice_view_user.php?page=".$i."'> 
                                                ".$i."</a></li>";   
          } 
        };   
        echo $pagLink;   
      ?> 
      </ul>  
	</div>
			
				   
</body>
</html>
