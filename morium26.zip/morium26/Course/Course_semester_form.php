<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; }
        .wrapper{ width: 350px; padding: 20px; }
		* {
			  margin: 0;
			}
			.top_head{
				overflow:hidden;
				height:70px;
				background:#128C41;
				text-align: center;
				padding:5px;
				
			}
			.top_child{
				overflow:hidden;
				height:60px;
				background:#333;
			}

			.top_child ul{
				margin-left:0px;
			}

			.top_child ul li{
			float:left;
			padding:17px;
			list-style-type: none;
			}

			.top_child ul li a{
			color:white;
			text-decoration:none;
			padding: 10px;
			}
			.top_child ul li a:hover{
				background:white;
				color:black;
				padding:10px 10px;
			}
			.middle_area
			{
			background-color:#B3CBD2;
			width:100%;
			overflow:hidden;
			height:500px;
			
			}
			.row{
            width:100%;
            }


           .column {
           float: left;
           width: 30%;
           padding: 10px;
           height: 500px; 
           }
           .column1 {
		   margin-left:50px;
           float: left;
           width: 65%;
           padding: 10px;
           height: 500px;
           margin-left:50px;		   
           }

			
				
    </style>
</head>
<body>
<div class="top_head">
		  <h1>IUBAT IT society management system</h1>
		</div>
		<div class="top_child">
			<ul>
				<li><a href="../after_admin_login_home.php">Home</a></li>
				<li><a href="">Notice</a></li>
				<li><a href="loantype.html">Mentoring Class</a></li>
				<li><a href="#">Member</a></li>
				<li><a href="#">Event</a></li>
				<li><a href="#">Finance</a></li>
				<li><a href="logout.php">Logout</a></li>
			</ul>
		</div>
<div class="middle_area">
<div class="row">
  <div class="column1" style="background-color:#B3CBD2;">
  <?php
$con=mysqli_connect("localhost","root","","morium");
// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
//print_r($_REQUEST);
$result = mysqli_query($con,"SELECT  id,semester FROM semester ORDER BY id DESC  ");
				 
while($row = mysqli_fetch_array($result)) 
	{ 
		$c=$row['id']  ;
            $a=$row['semester'];
            
			?>
			<p>
			<form action="Courseoffering_form.php" method="post" >
			<input type="hidden" value="<?php echo $row['id']; ?>" name="id">
			<input type="submit" value="<?php echo $row['semester']?>">
			<a style="color:red;" href="semester_delete.php?id=<?php echo $row['id'] ?>">Delete</a>
            </form>
			</p>
           
			<?php
				  
	}
	
	?>		 	
  </div>
   <div class="column" style="background-color:#bbb; text-align:center;"><h4>New Semester insert </h4><br>
  
			<div class="column2" style="text-align:center;" >
			   <h2></h2></br>
			  
        <form action="Semester_insert.php" method="post">
		
        <label for="semester">Semester Name:</label><br>
        <input type="text" name="semester" id="semester"><br>
		
    
    <input type="submit" value="Submit">
</form>
</div>
		</div>
  </div>

			 
   </div>
			
				   
</body>
</html>
