<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "", "morium");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
$e_id = mysqli_real_escape_string($link, $_REQUEST['e_id']);
$id=$e_id;
$result = mysqli_query($link,"SELECT  * FROM date WHERE e_id='$e_id'  ");
				 
while($row = mysqli_fetch_array($result)) 
	{ 
            $a=$row['date'];
	}
 $name = mysqli_real_escape_string($link, $_REQUEST['m_name']);
 $purpose = mysqli_real_escape_string($link, $_REQUEST['task_title']);
 $amount = mysqli_real_escape_string($link, $_REQUEST['amount']);
 $date =$a;
 
 $sql1 = "UPDATE event_task SET amount='$amount' WHERE 	e_id='$e_id' AND m_name='$name' AND task_title='$purpose'";
  mysqli_query($link, $sql1);
// Attempt upamount query execution
$sql = "INSERT into deduct_amount (e_id, name,purpose,amount,date,status) VALUES ('$e_id', '$name','$purpose','$amount','$date','0')";


if(mysqli_query($link, $sql)){
	header("Location: Deduct_event_form.php?id=$id");
    exit;
} else {
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>