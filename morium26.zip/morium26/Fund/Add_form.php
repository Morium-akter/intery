

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; }
        .wrapper{ width: 350px; padding: 20px; }
		* {
			  margin: 0;
			}
			.top_head{
				overflow:hidden;
				height:70px;
				background:#128C41;
				text-align: center;
				padding:5px;
				
			}
			.top_child{
				overflow:hidden;
				height:60px;
				background:#333;
			}

			.top_child ul{
				margin-left:0px;
			}

			.top_child ul li{
			float:left;
			padding:17px;
			list-style-type: none;
			}

			.top_child ul li a{
			color:white;
			text-decoration:none;
			padding: 10px;
			}
			.top_child ul li a:hover{
				background:white;
				color:black;
				padding:10px 10px;
			}
			.middle_area
			{
			background-color:#B3CBD2;
			width:100%;
			overflow:hidden;
			height:500px;
			
			}
			.column {
           float: left;
           width: 40%;
           padding: 10px;
           height: 500px; 
           }
           .column1 {
		   margin-left:40px;
           float: left;
           width: 40%;
           padding: 10px;
           height: 500px;
           margin-left:50px;
           text-align:center;		   
           
		   table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #B3CBD2;;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}			
				
    </style>
</head>
<body>
<div class="top_head">
		  <h1>IUBAT IT society management system</h1>
		</div>
		<div class="top_child">
			<ul>
				<li><a href="../after_admin_login_home.php">Home</a></li>
				<li><a href="">Notice</a></li>
				<li><a href="">Mentoring Class</a></li>
				<li><a href="#">Member</a></li>
				<li><a href="#">Event</a></li>
				<li><a href="../logout.php">Logout</a></li>
			</ul>
		</div>
		<div class="middle_area">
		
<div class="row">
  <div class="column1" style="background-color:#B3CBD2;"><h3>Please Fill up to add amount</h3>

<form action="Add_amount_insert.php" method="post">
  
  <label for="name">Name(Source of amount):</label><br>
  <input type="text" name="name" id="name"><br>
    <label for="purpose">Purpose:</label><br>
  <input type="text" name="purpose" id="purpose"><br>
    <label for="amount">Amount:</label><br>
  <input type="text" name="amount" id="amount"><br>
   <label for="date">Date:</label><br>
  <input type="date" name="date" id="date"><br>
  <input type="submit" value="Submit">
  
</form>
			 		 
    </div>
	<div class="column" style="background-color:#bbb; text-align:center;"><h3>Message</h3><br>
	<?php
	
	$con = mysqli_connect("localhost", "root", "", "morium");
 
// Check connection
if($con === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
	$result = mysqli_query($con,"SELECT  MAX(a_id) FROM add_amount ");
				 
while($row = mysqli_fetch_array($result)) 
	{ 
         $a= $row['MAX(a_id)'];  
	}
	$sql3 = "SELECT * FROM add_amount WHERE a_id='$a' ";   
    $rs_result3 = mysqli_query ($con,$sql3); 			 
    while($row = mysqli_fetch_array($rs_result3)) 
	{ 
         $name=$row['name'];
		 $pupose=$row['purpose'];
		 $amount=$row['amount'];
		 $date=$row['date'];
		 $status= $row['status'];
	} 
	  if($status=='1'){
		 ?><h3><?php echo "Name = ".$name.";  Purpose = ".$pupose.";  Amount = ".$amount.";  Date = ".$date.";   is Apporoved";?></h3><?php
		  
	  }
	   else if($status=='0'){
		  ?><h3><?phpecho "Name = ".$name.";  Purpose = ".$pupose.";  Amount = ".$amount.";  Date = ".$date.";   is pending";?></h3><?php
		  
	  }
	  else if($status=='2'){
		  ?><h3><?php echo "Name = ".$name.";  Purpose = ".$pupose.";  Amount = ".$amount.";  Date = ".$date.";   is Rejected";?></h3><?php
		  
	  }
	?>
	
	</div>
	
</div>
  			   
</body>
</html>
